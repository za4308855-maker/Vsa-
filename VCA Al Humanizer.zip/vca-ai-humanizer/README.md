# VCA AI Humanizer

A premium AI Humanizer / Human Language Converter website built with HTML, CSS, Vanilla JavaScript, Node.js, Express, and PostgreSQL.

## Project Structure (Phase 1)
- `frontend/`: Static assets, HTML, CSS, and Vanilla JS.
- `backend/`: Express server, API routes, controllers, and middleware.
- `database/`: SQL initialization scripts.
- `tests/`: Placeholder for future testing frameworks.

## Prerequisites
- Node.js (v18+ recommended)
- PostgreSQL (v14+ recommended)

## Setup Instructions

### 1. Database Setup
1. Open your PostgreSQL terminal (`psql`).
2. Create the database:
   ```sql
   CREATE DATABASE vca_humanizer;