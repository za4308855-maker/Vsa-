-- Phase 4: AI Jobs Migration
-- Creates table to track AI requests, isolate per-user caches, and prevent duplicates.

CREATE TABLE IF NOT EXISTS ai_jobs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    input_hash VARCHAR(64) NOT NULL,
    output_text TEXT,
    model_name VARCHAR(100) NOT NULL,
    job_type VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    processing_time INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_ai_jobs_user_id ON ai_jobs(user_id);

-- Prevent duplicate active (pending/processing) jobs
CREATE UNIQUE INDEX idx_unique_active_job 
ON ai_jobs (user_id, input_hash) 
WHERE status IN ('pending', 'processing');

-- Prevent duplicate completed cache rows
CREATE UNIQUE INDEX idx_unique_completed_job 
ON ai_jobs (user_id, input_hash) 
WHERE status = 'completed';

CREATE OR REPLACE FUNCTION update_ai_jobs_modtime()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_ai_jobs_modtime ON ai_jobs;
CREATE TRIGGER update_ai_jobs_modtime BEFORE UPDATE ON ai_jobs FOR EACH ROW EXECUTE FUNCTION update_ai_jobs_modtime();