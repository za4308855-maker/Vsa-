-- Phase 5: SEO Research & Blog Drafts
-- Additive migration. Does not touch Phase 1-4 tables.
-- Reuses update_modified_column() from Phase 3.

-- =========================
-- Table 1: seo_research
-- =========================
CREATE TABLE IF NOT EXISTS seo_research (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    job_id INTEGER REFERENCES ai_jobs(id) ON DELETE SET NULL,
    
    topic TEXT NOT NULL,
    target_country VARCHAR(10) NOT NULL DEFAULT 'US',
    target_language VARCHAR(10) NOT NULL DEFAULT 'en',
    research_depth VARCHAR(20) DEFAULT 'standard',
    
    primary_keyword VARCHAR(255),
    secondary_keywords JSONB DEFAULT '[]'::jsonb,
    search_intent VARCHAR(50),
    keyword_relevance JSONB DEFAULT '[]'::jsonb,
    suggested_titles JSONB DEFAULT '[]'::jsonb,
    meta_description TEXT,
    topic_clusters JSONB DEFAULT '[]'::jsonb,
    content_outline JSONB DEFAULT '[]'::jsonb,
    trend_insights JSONB DEFAULT '[]'::jsonb,
    
    data_source VARCHAR(50) NOT NULL DEFAULT 'ollama_inference',
    
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_seo_research_user_id ON seo_research(user_id);
CREATE INDEX IF NOT EXISTS idx_seo_research_created ON seo_research(created_at DESC);

-- =========================
-- Table 2: blog_drafts
-- =========================
CREATE TABLE IF NOT EXISTS blog_drafts (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    job_id INTEGER REFERENCES ai_jobs(id) ON DELETE SET NULL,
    seo_research_id INTEGER REFERENCES seo_research(id) ON DELETE SET NULL,
    
    title VARCHAR(500) NOT NULL,
    slug VARCHAR(500),
    meta_title VARCHAR(255),
    meta_description TEXT,
    content_markdown TEXT NOT NULL,
    faq JSONB DEFAULT '[]'::jsonb,
    
    target_word_count INTEGER,
    actual_word_count INTEGER,
    tone VARCHAR(50) DEFAULT 'professional',
    language VARCHAR(10) DEFAULT 'en',
    
    primary_keyword VARCHAR(255),
    secondary_keywords JSONB DEFAULT '[]'::jsonb,
    keyword_usage_stats JSONB DEFAULT '{}'::jsonb,
    
    status VARCHAR(20) DEFAULT 'draft',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_blog_drafts_user_id ON blog_drafts(user_id);
CREATE INDEX IF NOT EXISTS idx_blog_drafts_seo_id ON blog_drafts(seo_research_id);
CREATE INDEX IF NOT EXISTS idx_blog_drafts_status ON blog_drafts(status);
CREATE INDEX IF NOT EXISTS idx_blog_drafts_created ON blog_drafts(created_at DESC);

DROP TRIGGER IF EXISTS update_blog_drafts_modtime ON blog_drafts;
CREATE TRIGGER update_blog_drafts_modtime
    BEFORE UPDATE ON blog_drafts
    FOR EACH ROW EXECUTE FUNCTION update_modified_column();