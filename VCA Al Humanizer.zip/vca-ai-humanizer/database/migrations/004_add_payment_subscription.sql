-- Add required columns to existing tables
ALTER TABLE subscription_plans ADD COLUMN IF NOT EXISTS slug VARCHAR(50) UNIQUE;
ALTER TABLE subscription_plans ADD COLUMN IF NOT EXISTS price_monthly DECIMAL(10,2) DEFAULT 0;
ALTER TABLE subscription_plans ADD COLUMN IF NOT EXISTS price_yearly DECIMAL(10,2) DEFAULT 0;
ALTER TABLE subscription_plans ADD COLUMN IF NOT EXISTS included_credits INTEGER DEFAULT 0;
ALTER TABLE subscription_plans ADD COLUMN IF NOT EXISTS is_active BOOLEAN DEFAULT TRUE;
ALTER TABLE subscription_plans ADD COLUMN IF NOT EXISTS sort_order INTEGER DEFAULT 0;

-- Insert the actual plans
INSERT INTO subscription_plans 
    (name, slug, description, price_monthly, price_yearly, included_credits, is_active, sort_order)
VALUES
    ('Free',    'free',    'Get started with basic features.',         0.00,  0.00,  1000,   TRUE, 1),
    ('Basic',   'basic',   'For casual users.',                        9.00,  90.00, 10000,  TRUE, 2),
    ('Pro',     'pro',     'For professionals.',                       19.00, 190.00, 30000,  TRUE, 3),
    ('Premium', 'premium', 'For power users.',                         49.00, 490.00, 100000, TRUE, 4)
ON CONFLICT (slug) DO UPDATE 
SET price_monthly = EXCLUDED.price_monthly, 
    price_yearly = EXCLUDED.price_yearly, 
    included_credits = EXCLUDED.included_credits;