-- Phase 10: Asset Management & AI Agent (Gemini/OpenAI)

-- 1. AI Agent Usage Logs
CREATE TABLE IF NOT EXISTS agent_usage_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    provider VARCHAR(50) NOT NULL,
    model VARCHAR(100) NOT NULL,
    prompt_tokens INTEGER,
    completion_tokens INTEGER,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Default Settings for Assets & Agent
INSERT INTO website_settings (key, value) VALUES
    ('active_logo_light', '"logo-black.png"'),
    ('active_logo_dark', '"logo-white.png"'),
    ('active_favicon', '"favicon.ico"'),
    ('ai_agent_provider', '"openai"'),
    ('ai_agent_model', '"gpt-4o-mini"'),
    ('ai_agent_status', '"disabled"')
ON CONFLICT (key) DO NOTHING;