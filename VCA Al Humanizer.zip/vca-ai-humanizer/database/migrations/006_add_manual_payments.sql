-- Phase 9: EasyPaisa Manual Payments & WhatsApp Verification

-- 1. Create manual_orders table
CREATE TABLE IF NOT EXISTS manual_orders (
    id SERIAL PRIMARY KEY,
    order_id VARCHAR(50) UNIQUE NOT NULL,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    plan_id INTEGER NOT NULL REFERENCES subscription_plans(id) ON DELETE RESTRICT,
    billing_cycle VARCHAR(20) NOT NULL,
    amount DECIMAL(10,2) NOT NULL CHECK (amount >= 0),
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL,
    transaction_reference VARCHAR(255),
    screenshot_path VARCHAR(255),
    status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'awaiting_verification', 'approved', 'rejected'
    admin_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_manual_orders_user_id ON manual_orders(user_id);
CREATE INDEX IF NOT EXISTS idx_manual_orders_status ON manual_orders(status);
CREATE INDEX IF NOT EXISTS idx_manual_orders_order_id ON manual_orders(order_id);

DROP TRIGGER IF EXISTS update_manual_orders_modtime ON manual_orders;
CREATE TRIGGER update_manual_orders_modtime
    BEFORE UPDATE ON manual_orders
    FOR EACH ROW EXECUTE FUNCTION update_modified_column();

-- 2. Create payment_qr_codes table (Exactly 3 slots)
CREATE TABLE IF NOT EXISTS payment_qr_codes (
    id SERIAL PRIMARY KEY,
    slot_number INTEGER UNIQUE NOT NULL CHECK (slot_number IN (1, 2, 3)),
    image_path VARCHAR(255) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Seed 3 empty slots
INSERT INTO payment_qr_codes (slot_number, image_path, is_active) VALUES
(1, '', FALSE), (2, '', FALSE), (3, '', FALSE)
ON CONFLICT (slot_number) DO NOTHING;

-- 3. Add WhatsApp number setting
INSERT INTO website_settings (key, value) VALUES
('whatsapp_number', '"+923058735972"')
ON CONFLICT (key) DO NOTHING;