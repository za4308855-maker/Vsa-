-- Phase 7: Admin Dashboard & Website Management
-- Additive migration. No existing tables are dropped.

-- 1. Add user status for suspension/blocking
ALTER TABLE users ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active';
-- Values: 'active', 'suspended'

-- 2. Add error tracking to AI jobs for admin debugging
ALTER TABLE ai_jobs ADD COLUMN IF NOT EXISTS error_message TEXT;

-- 3. Create website_settings table
CREATE TABLE IF NOT EXISTS website_settings (
    key VARCHAR(100) PRIMARY KEY,
    value JSONB NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Seed default settings (idempotent)
INSERT INTO website_settings (key, value) VALUES
    ('site_name', '"VCA AI Humanizer"'),
    ('maintenance_mode', 'false'),
    ('announcement_banner', 'null'),
    ('support_email', '"support@vca.com"')
ON CONFLICT (key) DO NOTHING;

-- 4. Create audit_logs table
CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    admin_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action VARCHAR(100) NOT NULL,
    target_type VARCHAR(50),
    target_id VARCHAR(255),
    details JSONB,
    ip_address VARCHAR(45),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_admin ON audit_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created ON audit_logs(created_at DESC);