-- VCA AI Humanizer - Phase 3 Step 2 Seed Data
-- Inserts foundational data required for the app to function.
-- DOES NOT insert fake users or payment records.

INSERT INTO subscription_plans (name, description, price, word_limit, features) VALUES
('Free', 'Basic humanization for casual users.', 0.00, 500, '{"languages": ["en"], "support": "community"}'),
('Pro', 'Unlimited humanization and multi-language support.', 19.00, NULL, '{"languages": ["en", "es", "fr", "de"], "support": "priority"}'),
('Enterprise', 'Custom solutions for teams and businesses.', 0.00, NULL, '{"languages": ["all"], "support": "dedicated", "api_access": true}');