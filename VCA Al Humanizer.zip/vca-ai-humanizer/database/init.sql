-- Phase 1: Database Foundation
-- This file contains the initial setup for the PostgreSQL database.
-- Full application tables (users, conversions, etc.) will be added in the Database Development Phase.

CREATE TABLE IF NOT EXISTS system_health_checks (
    id SERIAL PRIMARY KEY,
    checked_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(50) NOT NULL
);

-- Insert a baseline record to verify connection
INSERT INTO system_health_checks (status) VALUES ('initial_setup');

-- VCA AI Humanizer - Master Database Initialization Script
-- Run this file to set up the entire database structure and initial data.

\i schema.sql
\i seed.sql