/**
 * Automated API Test Script
 * Run this using: npm test
 * 
 * Requirements: The server must be running on localhost:3000 and the database must be migrated.
 * Note: This script does not test Stripe or Ollama (requires live external services).
 */

const assert = require('assert');

const BASE_URL = 'http://localhost:3000/api';
let testUserEmail = `test_${Date.now()}@example.com`;
let testUserPass = 'SecurePassword123!';
let jwtCookie = '';

async function runTests() {
    console.log('--- Starting API Tests ---');

    // 1. Test Health Check
    try {
        const res = await fetch(`${BASE_URL}/health`);
        const data = await res.json();
        assert.strictEqual(res.status, 200);
        assert.strictEqual(data.status, 'success');
        console.log('✅ PASS: Health check');
    } catch (err) {
        console.error('❌ FAIL: Health check', err.message);
    }

    // 2. Test Signup
    try {
        const res = await fetch(`${BASE_URL}/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: 'Test User', email: testUserEmail, password: testUserPass })
        });
        const data = await res.json();
        assert.strictEqual(res.status, 201);
        console.log('✅ PASS: Signup');
    } catch (err) {
        console.error('❌ FAIL: Signup', err.message);
    }

    // 3. Test Validation (Short Password)
    try {
        const res = await fetch(`${BASE_URL}/auth/signup`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name: 'Test', email: `x_${Date.now()}@test.com`, password: '123' })
        });
        assert.strictEqual(res.status, 400); // Expect validation failure
        console.log('✅ PASS: Validation rejects short password');
    } catch (err) {
        console.error('❌ FAIL: Validation test', err.message);
    }

    // 4. Test Protected Route (Unauthorized)
    try {
        const res = await fetch(`${BASE_URL}/credits`);
        assert.strictEqual(res.status, 401);
        console.log('✅ PASS: Protected route blocks unauthorized user');
    } catch (err) {
        console.error('❌ FAIL: Protected route auth', err.message);
    }

    // 5. Test Admin Route (Forbidden for normal user)
    try {
        // We need to login first to get a cookie
        const loginRes = await fetch(`${BASE_URL}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: testUserEmail, password: testUserPass })
        });
        
        // Since we didn't verify OTP in this test, it will fail. 
        // In a real test, you would mock the OTP or verify via DB.
        console.log('ℹ️ INFO: Admin route test skipped because user is unverified (requires OTP).');
    } catch (err) {
        console.error('❌ FAIL: Admin route auth', err.message);
    }

    console.log('--- Tests Complete ---');
}

runTests();