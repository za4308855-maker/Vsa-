document.addEventListener('DOMContentLoaded', () => {
    let currentCycle = 'monthly';
    let plans = [];
    const container = document.getElementById('plans-container');

    if (!container) return;

    document.getElementById('monthly-btn')?.addEventListener('click', () => setCycle('monthly'));
    document.getElementById('yearly-btn')?.addEventListener('click', () => setCycle('yearly'));

    function setCycle(cycle) {
        currentCycle = cycle;
        document.getElementById('monthly-btn').classList.toggle('active', cycle === 'monthly');
        document.getElementById('yearly-btn').classList.toggle('active', cycle === 'yearly');
        if (plans.length > 0) render();
    }

    async function loadPlans() {
        try {
            const res = await fetch('/api/subscription/plans');
            
            if (!res.ok) {
                throw new Error(`Server error: ${res.status}`);
            }

            const data = await res.json();
            plans = data.data || [];
            
            if (plans.length === 0) {
                throw new Error('No plans found in database. Please add plans.');
            }
            
            render();
        } catch (err) {
            // Show error and a retry button
            container.innerHTML = `
                <div style="grid-column: 1/-1; text-align: center; padding: 2rem;">
                    <p style="color: var(--danger); margin-bottom: 1rem;">⚠️ ${err.message}</p>
                    <button onclick="location.reload()" class="btn btn-primary">Retry</button>
                </div>
            `;
        }
    }

    function render() {
        container.innerHTML = plans.map(plan => {
            const isFree = parseFloat(plan.price_monthly) === 0;
            const price = currentCycle === 'monthly' ? plan.price_monthly : plan.price_yearly;
            const period = currentCycle === 'monthly' ? '/mo' : '/yr';

            return `
                <div class="pricing-card glass-panel">
                    <h3>${plan.name}</h3>
                    <div class="price">$${parseFloat(price).toFixed(0)}<span>${isFree ? '' : period}</span></div>
                    <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 1rem;">${plan.description || ''}</p>
                    <p style="color: var(--sage-green); font-weight: 600; margin-bottom: 1rem;">${plan.included_credits.toLocaleString()} credits</p>
                    <button class="btn btn-primary" ${isFree ? 'disabled' : ''} style="width: 100%;">
                        ${isFree ? 'Current Plan' : 'Subscribe'}
                    </button>
                </div>
            `;
        }).join('');
    }

    loadPlans();
});