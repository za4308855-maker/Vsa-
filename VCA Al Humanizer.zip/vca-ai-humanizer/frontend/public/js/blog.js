document.addEventListener('DOMContentLoaded', () => {
    const generateBtn = document.getElementById('generate-btn');
    const statusMsg = document.getElementById('status-msg');
    const resultPanel = document.getElementById('result-panel');

    generateBtn.addEventListener('click', async () => {
        const title = document.getElementById('title').value.trim();
        const primaryKeyword = document.getElementById('primary-kw').value.trim();
        const secondaryKeywords = document.getElementById('secondary-kws').value.split(',').map(s => s.trim()).filter(s => s);
        const targetWordCount = parseInt(document.getElementById('word-count').value, 10);
        const tone = document.getElementById('tone').value;

        if (!title || !primaryKeyword) {
            showStatus('Please fill in the title and primary keyword.', 'error');
            return;
        }

        const originalText = generateBtn.textContent;
        generateBtn.textContent = 'Writing... (This may take several minutes)';
        generateBtn.disabled = true;
        statusMsg.className = 'status-msg';
        resultPanel.style.display = 'none';

        try {
            const res = await fetch('/api/blog/generate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    title, primaryKeyword, secondaryKeywords, 
                    targetWordCount, tone, language: 'en' 
                })
            });

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.message || 'Blog generation failed.');
            }

            renderBlog(data.data);
            showStatus(`Done in ${(data.processingTime / 1000).toFixed(1)}s. Used ${data.creditsUsed} credits.`, 'success');
            resultPanel.style.display = 'block';

        } catch (err) {
            showStatus(err.message, 'error');
        } finally {
            generateBtn.textContent = originalText;
            generateBtn.disabled = false;
        }
    });

    function renderBlog(data) {
        document.getElementById('res-meta-title').textContent = data.metaTitle || 'N/A';
        document.getElementById('res-meta-desc').textContent = data.metaDescription || 'N/A';
        
        // Parse Markdown to HTML safely
        const htmlContent = parseMarkdown(data.contentMarkdown);
        document.getElementById('blog-content').innerHTML = htmlContent;
    }

    // Lightweight Markdown Parser (Supports H1, H2, H3, bold, italic, paragraphs)
    function parseMarkdown(md) {
        if (!md) return '';
        let html = md;

        // Escape HTML to prevent XSS
        html = html.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

        // Headers
        html = html.replace(/^### (.*$)/gim, '<h3>$1</h3>');
        html = html.replace(/^## (.*$)/gim, '<h2>$1</h2>');
        html = html.replace(/^# (.*$)/gim, '<h1>$1</h1>');

        // Bold & Italic
        html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');

        // Paragraphs (split by double newline)
        const paragraphs = html.split(/\n\n+/);
        html = paragraphs.map(p => {
            if (p.startsWith('<h')) return p; // Don't wrap headers
            return `<p>${p.replace(/\n/g, '<br>')}</p>`;
        }).join('');

        return html;
    }

    function showStatus(message, type) {
        statusMsg.textContent = message;
        statusMsg.className = `status-msg ${type}`;
        if (type === 'success') {
            setTimeout(() => { statusMsg.className = 'status-msg'; }, 5000);
        }
    }
});