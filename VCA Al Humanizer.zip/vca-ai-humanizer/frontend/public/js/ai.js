/**
 * Centralized AI API client.
 * Handles fetch requests to /api/ai/* and surfaces real errors from the backend.
 */

async function apiRequest(endpoint, payload) {
    try {
        const res = await fetch(`/api/ai/${endpoint}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        // Guard against non-JSON responses (e.g., 502 from proxy)
        const contentType = res.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error(`Server returned non-JSON response (${res.status}).`);
        }

        const data = await res.json();

        if (!res.ok) {
            // Surface the exact backend message (e.g., "Insufficient credits", "Ollama not running")
            throw new Error(data.message || `Request failed with status ${res.status}.`);
        }

        return data;
    } catch (err) {
        // Distinguish network/CORS errors from API errors
        if (err.message === 'Failed to fetch') {
            throw new Error('Cannot reach the server. Is the backend running on port 3000?');
        }
        throw err;
    }
}

const AI = {
    humanize: (text, language, tone) => apiRequest('humanize', { text, language, tone }),
    translate: (text, targetLanguage) => apiRequest('translate', { text, targetLanguage })
};