/**
 * Reusable Skeleton Loading Utility
 */
const Skeleton = {
    // 1. Text lines
    textLines: (count = 3) => {
        let html = '';
        for (let i = 0; i < count; i++) {
            html += `<div class="skeleton sk-text" style="width: ${Math.random() * 30 + 70}%;"></div>`;
        }
        return html;
    },

    // 2. Card (Pricing, Features)
    card: () => `
        <div class="pricing-card glass-panel" style="pointer-events: none;">
            <div class="skeleton sk-title" style="margin: 0 auto 1rem;"></div>
            <div class="skeleton sk-text" style="width: 40%; margin: 0 auto 2rem; height: 40px;"></div>
            ${Skeleton.textLines(3)}
            <div class="skeleton sk-text" style="width: 100%; height: 40px; margin-top: 2rem; border-radius: 8px;"></div>
        </div>
    `,

    // 3. Table
    table: (cols = 5, rows = 5) => {
        let html = '';
        for (let i = 0; i < rows; i++) {
            html += `<tr>`;
            for (let j = 0; j < cols; j++) {
                html += `<td><div class="skeleton sk-text" style="margin:0; height: 20px;"></div></td>`;
            }
            html += `</tr>`;
        }
        return html;
    },

    // 4. Error with Retry
    error: (message, retryFn) => `
        <div style="text-align: center; padding: 3rem; color: var(--text-muted);">
            <h3 style="color: var(--danger); margin-bottom: 1rem;">⚠️ ${message}</h3>
            <button class="btn btn-primary" onclick="${retryFn}">Retry</button>
        </div>
    `
};