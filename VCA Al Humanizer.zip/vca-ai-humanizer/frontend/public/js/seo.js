document.addEventListener('DOMContentLoaded', () => {
    const researchBtn = document.getElementById('research-btn');
    const statusMsg = document.getElementById('status-msg');
    const resultPanel = document.getElementById('result-panel');

    researchBtn.addEventListener('click', async () => {
        const topic = document.getElementById('topic').value.trim();
        const targetCountry = document.getElementById('country').value;
        const targetLanguage = document.getElementById('language').value;
        const researchDepth = document.getElementById('depth').value;

        if (!topic) {
            showStatus('Please enter a topic.', 'error');
            return;
        }

        const originalText = researchBtn.textContent;
        researchBtn.textContent = 'Analyzing... (This may take a minute)';
        researchBtn.disabled = true;
        statusMsg.className = 'status-msg';
        resultPanel.style.display = 'none';

        try {
            const res = await fetch('/api/seo/research', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ topic, targetCountry, targetLanguage, researchDepth })
            });

            const data = await res.json();

            if (!res.ok) {
                throw new Error(data.message || 'Research failed.');
            }

            renderResults(data.data);
            showStatus(`Done in ${(data.processingTime / 1000).toFixed(1)}s. Used ${data.creditsUsed} credits.`, 'success');
            resultPanel.style.display = 'block';

        } catch (err) {
            showStatus(err.message, 'error');
        } finally {
            researchBtn.textContent = originalText;
            researchBtn.disabled = false;
        }
    });

    function renderResults(data) {
        document.getElementById('res-primary').textContent = data.primaryKeyword || 'N/A';
        document.getElementById('res-intent').textContent = data.searchIntent ? data.searchIntent.toUpperCase() : 'N/A';
        document.getElementById('res-meta').textContent = data.metaDescription || 'N/A';

        // Secondary Keywords
        const secContainer = document.getElementById('res-secondary');
        secContainer.innerHTML = '';
        (data.secondaryKeywords || []).forEach(kw => {
            const span = document.createElement('span');
            span.className = 'keyword-tag';
            span.textContent = kw;
            secContainer.appendChild(span);
        });

        // Titles
        const titlesList = document.getElementById('res-titles');
        titlesList.innerHTML = '';
        (data.suggestedTitles || []).forEach(t => {
            const li = document.createElement('li');
            li.innerHTML = `<strong>${t.title}</strong> <br><span style="font-size:0.85rem; color:var(--text-muted);">${t.reason}</span>`;
            titlesList.appendChild(li);
        });

        // Outline
        const outlineContainer = document.getElementById('res-outline');
        outlineContainer.innerHTML = '';
        (data.contentOutline || []).forEach(item => {
            const div = document.createElement('div');
            div.className = 'outline-item';
            const h3s = (item.h3s || []).map(h => `<li>${h}</li>`).join('');
            div.innerHTML = `
                <h4>${item.h2}</h4>
                <p style="font-size:0.85rem; color:var(--text-muted);">${item.notes || ''}</p>
                <ul>${h3s}</ul>
            `;
            outlineContainer.appendChild(div);
        });
    }

    function showStatus(message, type) {
        statusMsg.textContent = message;
        statusMsg.className = `status-msg ${type}`;
        if (type === 'success') {
            setTimeout(() => { statusMsg.className = 'status-msg'; }, 5000);
        }
    }
});