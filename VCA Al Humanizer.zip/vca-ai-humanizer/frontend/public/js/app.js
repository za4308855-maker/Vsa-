
// --- Reusable Footer Injection ---
document.addEventListener('DOMContentLoaded', () => {
    const footerElement = document.getElementById('main-footer');

    if (!footerElement) return;

    footerElement.innerHTML = `
        <div class="footer-container glass-panel">

            <div class="footer-grid">

                <div class="footer-brand">
                    <a href="./index.html">
                        <img
                            src="./public/assets/logos/logo-black.png"
                            alt="VCA AI Humanizer Logo"
                            class="logo logo-light"
                        >

                        <img
                            src="./public/assets/logos/logo-white.png"
                            alt="VCA AI Humanizer Logo"
                            class="logo logo-dark"
                        >
                    </a>

                    <p>
                        VCA AI Humanizer converts AI-generated text into
                        natural, human-like language. Our mission is to make
                        digital communication authentic and engaging.
                    </p>
                </div>

                <div class="footer-links">
                    <h4>AI Tools</h4>
                    <a href="./tool.html">AI Humanizer</a>
                    <a href="./converter.html">Language Converter</a>
                    <a href="./tool.html">Text Rewriting</a>
                </div>

                <div class="footer-links">
                    <h4>Resources</h4>
                    <a href="./how-to-use.html">How to Use</a>
                    <a href="./faq.html">FAQs</a>
                    <a href="./help-center.html">Help Center</a>
                </div>

                <div class="footer-links">
                    <h4>Company</h4>
                    <a href="./about.html">About Us</a>
                    <a href="./contact.html">Contact Us</a>
                </div>

                <div class="footer-links">
                    <h4>Legal</h4>
                    <a href="./privacy-policy.html">Privacy Policy</a>
                    <a href="./terms-and-conditions.html">Terms & Conditions</a>
                    <a href="./cookie-policy.html">Cookie Policy</a>
                    <a href="./refund-policy.html">Refund Policy</a>
                    <a href="./disclaimer.html">Disclaimer</a>
                </div>

            </div>

            <div class="footer-bottom">
                <p>
                    &copy; <span id="year"></span>
                    VCA AI Humanizer. All rights reserved.
                </p>
            </div>

        </div>
    `;

    // Automatically update copyright year
    const yearElement = footerElement.querySelector('#year');

    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
});
