document.addEventListener('DOMContentLoaded', () => {
    const sourceText = document.getElementById('source-text');
    const targetText = document.getElementById('target-text');
    const convertBtn = document.getElementById('convert-btn');
    const targetLangSelect = document.getElementById('target-lang');
    
    // Create a status message element dynamically if not in HTML
    let statusMsg = document.getElementById('convert-status');
    if (!statusMsg) {
        statusMsg = document.createElement('div');
        statusMsg.id = 'convert-status';
        statusMsg.className = 'status-msg';
        statusMsg.style.marginTop = '1rem';
        convertBtn.parentNode.appendChild(statusMsg);
    }

    convertBtn.addEventListener('click', async () => {
        const text = sourceText.value.trim();
        const targetLanguage = targetLangSelect.value;

        if (!text) {
            showStatus('Please enter text to convert.', 'error');
            return;
        }

        const originalBtnText = convertBtn.textContent;
        convertBtn.textContent = 'Converting...';
        convertBtn.disabled = true;
        statusMsg.className = 'status-msg';

        try {
            const result = await AI.translate(text, targetLanguage);
            targetText.value = result.output;
            
            if (result.cached) {
                showStatus('Loaded from cache (no credits used).', 'success');
            } else {
                showStatus(`Converted in ${(result.processingTime / 1000).toFixed(1)}s. Used ${result.wordCount} credits.`, 'success');
            }
        } catch (err) {
            showStatus(err.message, 'error');
        } finally {
            convertBtn.textContent = originalBtnText;
            convertBtn.disabled = false;
        }
    });

    function showStatus(message, type) {
        statusMsg.textContent = message;
        statusMsg.className = `status-msg ${type}`;
        if (type === 'success') {
            setTimeout(() => { statusMsg.className = 'status-msg'; }, 5000);
        }
    }
});