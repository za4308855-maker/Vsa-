// --- 6. LOGIN FLOW ---
const loginForm = document.getElementById('login-form');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;

        const submitBtn = loginForm.querySelector('button[type="submit"]');
        submitBtn.textContent = 'Logging in...';
        submitBtn.disabled = true;

        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            
            // Check if response is JSON before parsing to prevent parsing crashes
            const contentType = res.headers.get("content-type");
            if (!contentType || !contentType.includes("application/json")) {
                throw new Error("Server returned non-JSON response. Check backend logs.");
            }

            const data = await res.json();

            if (res.ok) {
                showMessage('login-msg', 'Login successful! Redirecting...', 'success');
                setTimeout(() => { window.location.href = 'dashboard.html'; }, 1000);
            } else {
                showMessage('login-msg', data.message || 'Login failed.', 'error');
            }
        } catch (error) {
            // Log actual error to console for debugging
            console.error('Login Fetch Error:', error);
            // Show actual error message in UI instead of generic string
            showMessage('login-msg', `Connection Error: ${error.message}`, 'error');
        } finally {
            submitBtn.textContent = 'Log In';
            submitBtn.disabled = false;
        }
    });
}