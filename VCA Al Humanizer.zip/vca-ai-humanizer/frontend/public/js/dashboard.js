document.addEventListener('DOMContentLoaded', async () => {
    try {
        const res = await fetch('/api/auth/me'); // Fetches the user based on the HTTP-only cookie
        if (!res.ok) {
            window.location.href = 'login.html'; // Kick out if not logged in
            return;
        }
        const data = await res.json();
        // User is authenticated. Data contains { user: { id: ..., email: ... } }
        console.log("Persistent User ID:", data.user.id);
    } catch (err) {
        window.location.href = 'login.html';
    }
});