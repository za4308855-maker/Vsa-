document.addEventListener('DOMContentLoaded', () => {
    const inputText = document.getElementById('input-text');
    const outputText = document.getElementById('output-text');
    const inputCount = document.getElementById('input-count');
    const outputCount = document.getElementById('output-count');
    const clearBtn = document.getElementById('clear-btn');
    const copyBtn = document.getElementById('copy-btn');
    const humanizeBtn = document.getElementById('humanize-btn');
    const statusMsg = document.getElementById('status-msg');
    const languageSelect = document.getElementById('language-select');
    const toneSelect = document.getElementById('tone-select');

    const updateCounters = (text, targetElement) => {
        const words = text.trim() === '' ? 0 : text.trim().split(/\s+/).length;
        const chars = text.length;
        targetElement.textContent = `${words} words | ${chars} characters`;
    };

    inputText.addEventListener('input', () => updateCounters(inputText.value, inputCount));

    clearBtn.addEventListener('click', () => {
        inputText.value = '';
        outputText.value = '';
        updateCounters('', inputCount);
        updateCounters('', outputCount);
        statusMsg.className = 'status-msg';
        statusMsg.textContent = '';
    });

    copyBtn.addEventListener('click', () => {
        if (!outputText.value) {
            showStatus('Nothing to copy!', 'error');
            return;
        }
        navigator.clipboard.writeText(outputText.value).then(() => {
            showStatus('Copied to clipboard!', 'success');
        }).catch(() => showStatus('Failed to copy text.', 'error'));
    });

    humanizeBtn.addEventListener('click', async () => {
        const text = inputText.value.trim();
        if (!text) {
            showStatus('Please enter some text to humanize.', 'error');
            return;
        }

        const originalBtnText = humanizeBtn.textContent;
        humanizeBtn.textContent = 'Processing...';
        humanizeBtn.disabled = true;
        statusMsg.className = 'status-msg'; // Clear previous

        try {
            // Call the centralized AI client
            const result = await AI.humanize(text, languageSelect.value, toneSelect.value);
            
            outputText.value = result.output;
            updateCounters(result.output, outputCount);
            
            if (result.cached) {
                showStatus('Loaded from cache (no credits used).', 'success');
            } else {
                showStatus(`Done in ${(result.processingTime / 1000).toFixed(1)}s. Used ${result.wordCount} credits.`, 'success');
            }
        } catch (err) {
            // Display the exact error (e.g., "Insufficient credits", "Ollama unreachable")
            showStatus(err.message, 'error');
        } finally {
            humanizeBtn.textContent = originalBtnText;
            humanizeBtn.disabled = false;
        }
    });

    function showStatus(message, type) {
        statusMsg.textContent = message;
        statusMsg.className = `status-msg ${type}`;
        // Keep errors visible longer, auto-hide success
        if (type === 'success') {
            setTimeout(() => { statusMsg.className = 'status-msg'; }, 5000);
        }
    }
});