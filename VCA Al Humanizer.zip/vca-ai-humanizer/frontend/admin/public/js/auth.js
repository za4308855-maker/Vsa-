const loginForm = document.getElementById('login-form');
if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault(); // CRITICAL: Stops the page from reloading and clearing fields
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const submitBtn = loginForm.querySelector('button[type="submit"]');
        
        submitBtn.textContent = 'Logging in...';
        submitBtn.disabled = true; // Prevents double submission

        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });
            const data = await res.json();

            if (res.ok) {
                showMessage('login-msg', 'Login successful! Redirecting...', 'success');
                setTimeout(() => { window.location.href = 'dashboard.html'; }, 1000);
            } else {
                // Do NOT clear fields on failure
                showMessage('login-msg', data.message || 'Invalid credentials.', 'error');
            }
        } catch (error) {
            showMessage('login-msg', 'Server error. Please try again.', 'error');
        } finally {
            submitBtn.textContent = 'Log In';
            submitBtn.disabled = false;
        }
    });
}