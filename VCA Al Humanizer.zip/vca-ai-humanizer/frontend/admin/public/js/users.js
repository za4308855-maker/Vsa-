document.addEventListener('DOMContentLoaded', () => {
    const tbody = document.getElementById('users-tbody');
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    
    if (!tbody) return;

    async function loadUsers(search = '') {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Loading...</td></tr>';
        try {
            const res = await Admin.fetch(`/api/admin/users?search=${encodeURIComponent(search)}`);
            renderUsers(res.data);
        } catch (err) {
            tbody.innerHTML = `<tr><td colspan="7" style="color: var(--danger); text-align: center;">${Admin.escapeHtml(err.message)}</td></tr>`;
        }
    }

    function renderUsers(users) {
        if (users.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No users found.</td></tr>';
            return;
        }

        tbody.innerHTML = users.map(u => {
            const isSuspended = u.status === 'suspended';
            const statusBadge = isSuspended 
                ? '<span class="badge badge-danger">Suspended</span>' 
                : '<span class="badge badge-success">Active</span>';
            
            return `
                <tr>
                    <td>${u.id}</td>
                    <td>
                        <strong>${Admin.escapeHtml(u.first_name || '')} ${Admin.escapeHtml(u.last_name || '')}</strong><br>
                        <span style="font-size: 0.85rem; color: var(--text-muted);">${Admin.escapeHtml(u.email)}</span>
                    </td>
                    <td>${Admin.escapeHtml(u.plan_name || 'None')}</td>
                    <td>${(u.credits || 0).toLocaleString()}</td>
                    <td>${statusBadge}</td>
                    <td>${new Date(u.created_at).toLocaleDateString()}</td>
                    <td>
                        <button class="btn btn-outline" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="viewUser(${u.id})">View</button>
                        <button class="btn ${isSuspended ? 'btn-primary' : 'btn-outline'}" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="toggleStatus(${u.id}, '${isSuspended ? 'active' : 'suspended'}')">
                            ${isSuspended ? 'Activate' : 'Suspend'}
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    window.toggleStatus = async (userId, newStatus) => {
        if (!confirm(`Are you sure you want to ${newStatus === 'active' ? 'activate' : 'suspend'} this user?`)) return;
        try {
            await Admin.fetch(`/api/admin/users/${userId}/status`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus })
            });
            loadUsers(searchInput.value);
        } catch (err) {
            alert(err.message);
        }
    };

    window.viewUser = async (userId) => {
        const modal = document.getElementById('user-modal');
        const modalBody = document.getElementById('modal-body');
        modal.classList.add('active');
        modalBody.innerHTML = 'Loading...';

        try {
            const res = await Admin.fetch(`/api/admin/users/${userId}`);
            const { user, recentJobs, recentPayments } = res.data;

            modalBody.innerHTML = `
                <p><strong>Email:</strong> ${Admin.escapeHtml(user.email)}</p>
                <p><strong>Status:</strong> ${user.status}</p>
                <p><strong>Credits:</strong> ${user.credits || 0}</p>
                <p><strong>Joined:</strong> ${new Date(user.created_at).toLocaleString()}</p>
                
                <h4 style="margin-top: 1.5rem; margin-bottom: 0.5rem;">Recent AI Jobs</h4>
                <ul style="margin-left: 1.5rem; font-size: 0.9rem;">
                    ${recentJobs.length ? recentJobs.map(j => `<li>${j.job_type} - ${j.status} (${j.processing_time || 0}ms)</li>`).join('') : '<li>None</li>'}
                </ul>

                <h4 style="margin-top: 1.5rem; margin-bottom: 0.5rem;">Recent Payments</h4>
                <ul style="margin-left: 1.5rem; font-size: 0.9rem;">
                    ${recentPayments.length ? recentPayments.map(p => `<li>$${p.amount} - ${p.status} (${p.provider})</li>`).join('') : '<li>None</li>'}
                </ul>
            `;
        } catch (err) {
            modalBody.innerHTML = `<p style="color: var(--danger);">${err.message}</p>`;
        }
    };

    searchBtn.addEventListener('click', () => loadUsers(searchInput.value));
    searchInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') loadUsers(searchInput.value); });

    loadUsers();
});