document.addEventListener('DOMContentLoaded', () => {
    const ordersTbody = document.getElementById('orders-tbody');
    const plansTbody = document.getElementById('plans-tbody');
    const planForm = document.getElementById('edit-plan-form');
    const searchInput = document.getElementById('search-orders');
    const searchBtn = document.getElementById('search-btn');

    if (!ordersTbody) return;

    // --- Manual Orders ---
    async function loadOrders(search = '') {
        ordersTbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Loading...</td></tr>';
        try {
            const res = await Admin.fetch(`/api/admin/manual-payments/orders?search=${encodeURIComponent(search)}`);
            if (res.data.length === 0) {
                ordersTbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No manual orders found.</td></tr>';
                return;
            }
            ordersTbody.innerHTML = res.data.map(o => {
                const badgeClass = o.status === 'approved' ? 'badge-success' : o.status === 'rejected' ? 'badge-danger' : 'badge-warning';
                
                let actionButtons = '';
                if (o.status === 'awaiting_verification') {
                    actionButtons = `
                        <button class="btn btn-primary" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="approveOrder('${o.order_id}')">Approve</button>
                        <button class="btn btn-outline" style="padding: 0.2rem 0.5rem; font-size: 0.8rem; color: var(--danger);" onclick="rejectOrder('${o.order_id}')">Reject</button>
                    `;
                }

                const screenshotLink = o.screenshot_path 
                    ? `<a href="/api/admin/manual-payments/orders/${o.order_id}/screenshot" target="_blank" class="badge badge-info">View Screenshot</a>` 
                    : 'None';

                return `
                    <tr>
                        <td><strong>${Admin.escapeHtml(o.order_id)}</strong></td>
                        <td>
                            ${Admin.escapeHtml(o.customer_name)}<br>
                            <span style="font-size: 0.8rem; color: var(--text-muted);">${Admin.escapeHtml(o.customer_email)}</span>
                        </td>
                        <td>${Admin.escapeHtml(o.plan_name)}<br>Rs. ${parseFloat(o.amount).toFixed(2)}</td>
                        <td>
                            Ref: ${Admin.escapeHtml(o.transaction_reference || 'N/A')}<br>
                            ${screenshotLink}
                        </td>
                        <td><span class="badge ${badgeClass}">${o.status}</span></td>
                        <td>${new Date(o.created_at).toLocaleString()}</td>
                        <td>${actionButtons}</td>
                    </tr>
                `;
            }).join('');
        } catch (err) {
            ordersTbody.innerHTML = `<tr><td colspan="7" style="color: var(--danger);">${Admin.escapeHtml(err.message)}</td></tr>`;
        }
    }

    window.approveOrder = async (orderId) => {
        if (!confirm('Are you sure you want to approve this payment? This will immediately activate the subscription and grant credits.')) return;
        try {
            await Admin.fetch(`/api/admin/manual-payments/orders/${orderId}/approve`, { method: 'POST' });
            alert('Order approved successfully.');
            loadOrders(searchInput.value);
        } catch (err) {
            alert(err.message);
        }
    };

    window.rejectOrder = async (orderId) => {
        if (!confirm('Are you sure you want to reject this payment?')) return;
        try {
            await Admin.fetch(`/api/admin/manual-payments/orders/${orderId}/reject`, { method: 'POST' });
            alert('Order rejected.');
            loadOrders(searchInput.value);
        } catch (err) {
            alert(err.message);
        }
    };

    searchBtn?.addEventListener('click', () => loadOrders(searchInput.value));
    searchInput?.addEventListener('keypress', (e) => { if (e.key === 'Enter') loadOrders(searchInput.value); });

    // --- Plans Management (Existing Phase 6/7 Logic) ---
    async function loadPlans() {
        try {
            const res = await Admin.fetch('/api/admin/billing/plans');
            plansTbody.innerHTML = res.data.map(p => `
                <tr>
                    <td>${p.id}</td>
                    <td><strong>${Admin.escapeHtml(p.name)}</strong></td>
                    <td>Rs. ${parseFloat(p.price_monthly).toFixed(2)}</td>
                    <td>Rs. ${parseFloat(p.price_yearly).toFixed(2)}</td>
                    <td>${(p.included_credits || 0).toLocaleString()}</td>
                    <td>${p.is_active ? '<span class="badge badge-success">Active</span>' : '<span class="badge badge-danger">Inactive</span>'}</td>
                    <td>
                        <button class="btn btn-outline" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick='openEditModal(${JSON.stringify(p)})'>Edit</button>
                    </td>
                </tr>
            `).join('');
        } catch (err) {
            plansTbody.innerHTML = `<tr><td colspan="7" style="color: var(--danger);">${Admin.escapeHtml(err.message)}</td></tr>`;
        }
    }

    window.openEditModal = (plan) => {
        document.getElementById('edit-plan-id').value = plan.id;
        document.getElementById('edit-plan-name').value = plan.name;
        document.getElementById('edit-plan-monthly').value = plan.price_monthly;
        document.getElementById('edit-plan-yearly').value = plan.price_yearly;
        document.getElementById('edit-plan-credits').value = plan.included_credits;
        document.getElementById('edit-plan-active').checked = plan.is_active;
        document.getElementById('plan-modal').classList.add('active');
    };

    planForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const id = document.getElementById('edit-plan-id').value;
        const payload = {
            price_monthly: parseFloat(document.getElementById('edit-plan-monthly').value),
            price_yearly: parseFloat(document.getElementById('edit-plan-yearly').value),
            included_credits: parseInt(document.getElementById('edit-plan-credits').value, 10),
            is_active: document.getElementById('edit-plan-active').checked
        };

        try {
            await Admin.fetch(`/api/admin/billing/plans/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            document.getElementById('plan-modal').classList.remove('active');
            loadPlans();
        } catch (err) {
            alert(err.message);
        }
    });

    loadOrders();
    loadPlans();
});