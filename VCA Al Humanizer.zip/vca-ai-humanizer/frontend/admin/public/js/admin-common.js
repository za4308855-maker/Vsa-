// Centralized Auth & Fetch Logic for Admin Panel
const Admin = {
    // 1. Initialization (Auth check & Sidebar injection)
    init: async function() {
        try {
            const res = await fetch('/api/auth/me');
            if (!res.ok) throw new Error('Not logged in');
            const data = await res.json();
            
            if (!data.user.is_admin) {
                alert('Access Denied. Admin privileges required.');
                window.location.href = '/index.html';
                return;
            }
            
            this.renderSidebar(data.user);
        } catch (err) {
            window.location.href = '/login.html';
        }
    },

    // 2. Fetch Wrapper (Handles JSON parsing & 401/403)
    fetch: async function(endpoint, options = {}) {
        const res = await fetch(endpoint, options);
        
        if (res.status === 401 || res.status === 403) {
            window.location.href = '/login.html';
            throw new Error('Unauthorized');
        }
        
        const contentType = res.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            throw new Error(`Server error (${res.status}). Check backend logs.`);
        }
        
        const data = await res.json();
        if (!res.ok) throw new Error(data.message || 'Request failed');
        return data;
    },

    // 3. HTML Escaping to prevent XSS
    escapeHtml: function(str) {
        return String(str || '').replace(/[&<>"']/g, function(m) {
            if (m === '&') return '&amp;';
            if (m === '<') return '&lt;';
            if (m === '>') return '&gt;';
            if (m === '"') return '&quot;';
            if (m === "'") return '&#039;';
        });
    },

    // 4. Sidebar Renderer
    renderSidebar: function(user) {
        const sidebar = document.getElementById('sidebar');
        if (!sidebar) return;

        const currentPath = window.location.pathname;
        const link = (href, label) => `
            <a href="${href}" class="admin-nav-link ${currentPath.includes(href) ? 'active' : ''}">
                ${label}
            </a>
        `;

        sidebar.innerHTML = `
            <div class="logo">
                <img src="/public/assets/logo-black.png" alt="VCA Logo" class="logo-light" style="height:32px;">
                <img src="/public/assets/logo-white.png" alt="VCA Logo" class="logo-dark" style="height:32px;">
                <div style="font-size:0.75rem; color:var(--sage-green); font-weight:bold; margin-top:0.5rem;">ADMIN PANEL</div>
            </div>
            <nav style="flex:1;">
                ${link('/admin/index.html', 'Dashboard')}
                ${link('/admin/users.html', 'User Management')}
                ${link('/admin/ai.html', 'AI Management')}
                ${link('/admin/billing.html', 'Billing & Plans')}
                ${link('/admin/content.html', 'Content')}
                ${link('/admin/settings.html', 'Website Settings')}
            </nav>
            <div style="margin-top: auto; padding-top: 2rem;">
                <p style="font-size:0.8rem; color:var(--text-muted); margin-bottom:1rem;">Logged in as<br><strong>${this.escapeHtml(user.email)}</strong></p>
                <button onclick="window.location.href='/index.html'" class="btn btn-outline" style="width:100%;">Exit to Site</button>
            </div>
        `;
        
        // Add mobile menu toggle
        const header = document.querySelector('.admin-header');
        if (header && window.innerWidth <= 768) {
            const toggleBtn = document.createElement('button');
            toggleBtn.className = 'btn btn-outline';
            toggleBtn.textContent = '☰ Menu';
            toggleBtn.style.marginTop = '1rem';
            toggleBtn.onclick = () => sidebar.classList.toggle('active');
            header.parentNode.insertBefore(toggleBtn, header.nextSibling);
        }
    }
};

// Auto-init on page load
document.addEventListener('DOMContentLoaded', () => Admin.init());