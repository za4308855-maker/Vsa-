// --- AI Agent Settings ---
const agentForm = document.getElementById('agent-form');
const testAgentBtn = document.getElementById('test-agent-btn');
const agentMsg = document.getElementById('agent-test-msg');

if (agentForm) {
    // Load agent settings
    fetch('/api/admin/settings', { headers: { 'Authorization': `Bearer ${localStorage.getItem('jwt')}` } }) // Use Admin.fetch logic
        .then(r => r.json()).then(res => {
            document.getElementById('agent-provider').value = res.settings.ai_agent_provider || 'openai';
            document.getElementById('agent-model').value = res.settings.ai_agent_model || 'gpt-4o-mini';
        });

    agentForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            ai_agent_provider: document.getElementById('agent-provider').value,
            ai_agent_model: document.getElementById('agent-model').value
        };
        try {
            await Admin.fetch('/api/admin/settings', {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            alert('Agent settings saved.');
        } catch (err) { alert(err.message); }
    });

    testAgentBtn.addEventListener('click', async () => {
        agentMsg.textContent = 'Testing...';
        agentMsg.style.color = 'var(--text-muted)';
        try {
            const provider = document.getElementById('agent-provider').value;
            const model = document.getElementById('agent-model').value;
            const res = await Admin.fetch('/api/agent/admin/test', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ provider, model })
            });
            agentMsg.textContent = '✅ Connection successful!';
            agentMsg.style.color = 'var(--success)';
        } catch (err) {
            agentMsg.textContent = `❌ Error: ${err.message}`;
            agentMsg.style.color = 'var(--danger)';
        }
    });
}