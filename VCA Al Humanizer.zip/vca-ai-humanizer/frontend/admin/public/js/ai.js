document.addEventListener('DOMContentLoaded', () => {
    const statusEl = document.getElementById('ollama-status');
    const modelsEl = document.getElementById('ollama-models');
    const tbody = document.getElementById('jobs-tbody');
    const filter = document.getElementById('job-filter');

    if (!statusEl) return;

    async function checkOllama() {
        try {
            const res = await Admin.fetch('/api/admin/ai/status');
            if (res.online) {
                statusEl.innerHTML = '<span class="badge badge-success">Online</span>';
                modelsEl.textContent = `Available Models: ${res.models.join(', ') || 'None pulled'}`;
            } else {
                statusEl.innerHTML = '<span class="badge badge-danger">Offline</span>';
                modelsEl.textContent = res.error;
            }
            document.getElementById('cfg-model').textContent = res.configuredModel;
        } catch (err) {
            statusEl.innerHTML = '<span class="badge badge-danger">Error checking status</span>';
        }
    }

    async function loadSettings() {
        try {
            const res = await Admin.fetch('/api/admin/ai/settings');
            const data = res.data;
            document.getElementById('cfg-max-words').textContent = data.maxWords;
            document.getElementById('cfg-timeout').textContent = data.timeoutMs;
            document.getElementById('cfg-seo').textContent = `Q:${data.seoCosts.quick} / S:${data.seoCosts.standard} / D:${data.seoCosts.deep}`;
        } catch (err) { console.error('Settings error', err); }
    }

    async function loadJobs(status = '') {
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Loading...</td></tr>';
        try {
            const res = await Admin.fetch(`/api/admin/ai/jobs?status=${status}`);
            if (res.data.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No jobs found.</td></tr>';
                return;
            }

            tbody.innerHTML = res.data.map(job => {
                const statusClass = job.status === 'completed' ? 'badge-success' : job.status === 'failed' ? 'badge-danger' : 'badge-warning';
                return `
                    <tr>
                        <td>${job.id}</td>
                        <td>${Admin.escapeHtml(job.email)}</td>
                        <td>${Admin.escapeHtml(job.job_type)}</td>
                        <td>${Admin.escapeHtml(job.model_name)}</td>
                        <td><span class="badge ${statusClass}">${job.status}</span></td>
                        <td>${job.processing_time ? job.processing_time + 'ms' : '--'}</td>
                        <td style="color: var(--danger); font-size: 0.85rem; max-width: 200px; overflow-wrap: break-word;">
                            ${Admin.escapeHtml(job.error_message || '')}
                        </td>
                    </tr>
                `;
            }).join('');
        } catch (err) {
            tbody.innerHTML = `<tr><td colspan="7" style="color: var(--danger);">${Admin.escapeHtml(err.message)}</td></tr>`;
        }
    }

    filter.addEventListener('change', () => loadJobs(filter.value));

    checkOllama();
    loadSettings();
    loadJobs();
});
const contentType = res.headers.get('content-type');
if (!contentType || !contentType.includes('application/json')) {
    // If it's HTML, don't try to parse it
    throw new Error(`Server error (${res.status}). Please check backend logs.`);
}