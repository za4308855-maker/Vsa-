document.addEventListener('DOMContentLoaded', () => {
    const blogsTbody = document.getElementById('blogs-tbody');
    const seoTbody = document.getElementById('seo-tbody');

    if (!blogsTbody) return;

    async function loadBlogs() {
        try {
            const res = await Admin.fetch('/api/admin/content/blogs');
            if (res.data.length === 0) {
                blogsTbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No blogs found.</td></tr>';
                return;
            }
            blogsTbody.innerHTML = res.data.map(b => `
                <tr>
                    <td>${b.id}</td>
                    <td>${Admin.escapeHtml(b.email)}</td>
                    <td style="max-width: 250px;">${Admin.escapeHtml(b.title)}</td>
                    <td>${b.actual_word_count || 0}</td>
                    <td>
                        <select onchange="updateBlogStatus(${b.id}, this.value)" class="form-control" style="padding: 0.2rem; font-size: 0.85rem;">
                            <option value="draft" ${b.status === 'draft' ? 'selected' : ''}>Draft</option>
                            <option value="published" ${b.status === 'published' ? 'selected' : ''}>Published</option>
                            <option value="archived" ${b.status === 'archived' ? 'selected' : ''}>Archived</option>
                        </select>
                    </td>
                    <td>${new Date(b.created_at).toLocaleDateString()}</td>
                    <td>
                        <a href="/blog-writer.html?id=${b.id}" target="_blank" class="btn btn-outline" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;">View</a>
                    </td>
                </tr>
            `).join('');
        } catch (err) {
            blogsTbody.innerHTML = `<tr><td colspan="7" style="color: var(--danger);">${Admin.escapeHtml(err.message)}</td></tr>`;
        }
    }

    async function loadSEO() {
        try {
            const res = await Admin.fetch('/api/admin/content/seo');
            if (res.data.length === 0) {
                seoTbody.innerHTML = '<tr><td colspan="6" style="text-align: center;">No SEO records found.</td></tr>';
                return;
            }
            seoTbody.innerHTML = res.data.map(s => `
                <tr>
                    <td>${s.id}</td>
                    <td>${Admin.escapeHtml(s.email)}</td>
                    <td style="max-width: 250px;">${Admin.escapeHtml(s.topic)}</td>
                    <td><span class="badge badge-info">${Admin.escapeHtml(s.primary_keyword)}</span></td>
                    <td>${Admin.escapeHtml(s.search_intent)}</td>
                    <td>${new Date(s.created_at).toLocaleDateString()}</td>
                </tr>
            `).join('');
        } catch (err) {
            seoTbody.innerHTML = `<tr><td colspan="6" style="color: var(--danger);">${Admin.escapeHtml(err.message)}</td></tr>`;
        }
    }

    window.updateBlogStatus = async (id, status) => {
        try {
            await Admin.fetch(`/api/admin/content/blogs/${id}/status`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status })
            });
            // Optional: Toast notification here
        } catch (err) {
            alert(err.message);
            loadBlogs(); // Revert visual change on failure
        }
    };

    loadBlogs();
    loadSEO();
});