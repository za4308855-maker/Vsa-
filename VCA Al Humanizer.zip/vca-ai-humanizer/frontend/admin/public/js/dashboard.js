document.addEventListener('DOMContentLoaded', async () => {
    if (!document.getElementById('stat-users')) return;

    try {
        const res = await Admin.fetch('/api/admin/dashboard/stats');
        const stats = res.data;

        document.getElementById('stat-users').textContent = stats.totalUsers;
        document.getElementById('stat-subs').textContent = stats.activeSubscriptions;
        document.getElementById('stat-revenue').textContent = `$${stats.totalRevenue.toFixed(2)}`;
        document.getElementById('stat-credits').textContent = stats.totalCreditsUsed.toLocaleString();
        document.getElementById('stat-jobs').textContent = stats.totalAiJobs;
        document.getElementById('stat-seo').textContent = stats.totalSeoResearch;
        document.getElementById('stat-blogs').textContent = stats.totalBlogDrafts;
    } catch (err) {
        console.error('Dashboard error:', err);
        alert('Failed to load stats: ' + err.message);
    }
});