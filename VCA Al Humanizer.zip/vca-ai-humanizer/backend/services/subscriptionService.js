/**
 * Subscription Service - Reads and writes for subscription records.
 * Handles plan lookup, current-subscription query, and Free-plan assignment.
 */

const db = require('../database');

async function getActivePlans() {
    const result = await db.query(
        `SELECT id, name, slug, description, price_monthly, price_yearly, included_credits, features
         FROM subscription_plans
         WHERE is_active = TRUE
         ORDER BY sort_order ASC`
    );
    return result.rows;
}

async function getPlanBySlug(slug) {
    const result = await db.query(
        'SELECT * FROM subscription_plans WHERE slug = $1 AND is_active = TRUE',
        [slug]
    );
    return result.rows[0] || null;
}

async function getPlanById(planId) {
    const result = await db.query('SELECT * FROM subscription_plans WHERE id = $1', [planId]);
    return result.rows[0] || null;
}

/**
 * Get current subscription for a user (latest active/past_due one).
 */
async function getUserSubscription(userId) {
    const result = await db.query(
        `SELECT s.*, p.name AS plan_name, p.slug AS plan_slug, p.included_credits, p.features
         FROM user_subscriptions s
         JOIN subscription_plans p ON s.plan_id = p.id
         WHERE s.user_id = $1 AND s.status IN ('active', 'past_due', 'trialing')
         ORDER BY s.created_at DESC
         LIMIT 1`,
        [userId]
    );
    return result.rows[0] || null;
}

/**
 * Assign the Free plan to a brand-new user (called during signup).
 * Idempotent: skips if the user already has any subscription row.
 */
async function ensureFreeSubscription(client, userId) {
    // Check if user already has a subscription
    const existing = await client.query(
        'SELECT id FROM user_subscriptions WHERE user_id = $1 LIMIT 1',
        [userId]
    );
    if (existing.rows.length > 0) return null;

    const freePlan = await client.query(
        'SELECT id, included_credits FROM subscription_plans WHERE slug = $1',
        ['free']
    );
    if (freePlan.rows.length === 0) {
        console.warn('Free plan not found — skipping subscription assignment for user', userId);
        return null;
    }

    const plan = freePlan.rows[0];
    const result = await client.query(
        `INSERT INTO user_subscriptions
         (user_id, plan_id, status, billing_cycle, current_period_start, current_period_end, start_date)
         VALUES ($1, $2, 'active', 'monthly', NOW(), NOW() + INTERVAL '100 years', NOW())
         RETURNING id`,
        [userId, plan.id]
    );

    // Grant initial Free credits
    await client.query(
        `INSERT INTO credit_transactions
         (user_id, delta, balance_after, transaction_type, reference_id, description)
         SELECT $1, $2, COALESCE((SELECT balance FROM user_credits WHERE user_id = $1), 0) + $2,
                'subscription_grant', 'free_signup:' || $1, 'Initial Free plan credits'
         WHERE NOT EXISTS (
             SELECT 1 FROM credit_transactions
             WHERE user_id = $1 AND reference_id = 'free_signup:' || $1 AND transaction_type = 'subscription_grant'
         )`,
        [userId, plan.included_credits]
    );

    await client.query(
        `UPDATE user_credits SET balance = balance + $2, updated_at = NOW()
         WHERE user_id = $1
           AND NOT EXISTS (
             SELECT 1 FROM credit_transactions
             WHERE user_id = $1 AND reference_id = 'free_signup:' || $1
               AND transaction_type = 'subscription_grant'
               AND delta = $2
               AND created_at > NOW() - INTERVAL '5 seconds'
           )`,
        [userId, plan.included_credits]
    );

    return result.rows[0].id;
}

async function getBillingHistory(userId, limit = 20, offset = 0) {
    const result = await db.query(
        `SELECT id, amount, currency, status, description, provider, transaction_reference, created_at
         FROM payment_transactions
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT $2 OFFSET $3`,
        [userId, limit, offset]
    );
    return result.rows;
}

module.exports = {
    getActivePlans,
    getPlanBySlug,
    getPlanById,
    getUserSubscription,
    ensureFreeSubscription,
    getBillingHistory
};