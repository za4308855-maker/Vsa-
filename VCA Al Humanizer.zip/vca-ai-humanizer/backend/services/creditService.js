/**
 * Credit Service - Single source of truth for all credit writes.
 * Every balance change MUST go through this service to guarantee:
 *   1. Transactional atomicity (balance + ledger written together)
 *   2. Duplicate prevention via UNIQUE(user_id, reference_id, transaction_type)
 *   3. Row-level locking to prevent race conditions
 */

const db = require('../database');

/**
 * Add credits (grant). Idempotent via reference_id.
 * Returns { balance, duplicated } where duplicated=true means already applied.
 */
async function grantCredits(client, { userId, amount, transactionType, referenceId, description, metadata }) {
    if (amount <= 0) throw new Error('Grant amount must be positive.');

    // Lock user_credits row to prevent concurrent writes
    const locked = await client.query(
        'SELECT balance FROM user_credits WHERE user_id = $1 FOR UPDATE',
        [userId]
    );
    if (locked.rows.length === 0) {
        // Ensure row exists (should not happen in practice — signup creates it)
        await client.query(
            'INSERT INTO user_credits (user_id, balance) VALUES ($1, 0) ON CONFLICT (user_id) DO NOTHING',
            [userId]
        );
    }
    const currentBalance = (await client.query(
        'SELECT balance FROM user_credits WHERE user_id = $1 FOR UPDATE',
        [userId]
    )).rows[0].balance;

    const newBalance = currentBalance + amount;

    // Insert ledger entry first — UNIQUE constraint aborts if this is a replay
    let ledgerId;
    try {
        const ledger = await client.query(
            `INSERT INTO credit_transactions
             (user_id, delta, balance_after, transaction_type, reference_id, description, metadata)
             VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
            [userId, amount, newBalance, transactionType, referenceId || null, description || null, metadata ? JSON.stringify(metadata) : null]
        );
        ledgerId = ledger.rows[0].id;
    } catch (err) {
        if (err.code === '23505') {
            // Already processed (idempotent)
            return { balance: currentBalance, duplicated: true };
        }
        throw err;
    }

    await client.query(
        'UPDATE user_credits SET balance = $1, updated_at = NOW() WHERE user_id = $2',
        [newBalance, userId]
    );

    return { balance: newBalance, duplicated: false, ledgerId };
}

/**
 * Deduct credits (AI usage). Idempotent via reference_id.
 * Throws 402-mapped error if insufficient balance.
 */
async function deductCredits(client, { userId, amount, transactionType, referenceId, description, metadata }) {
    if (amount <= 0) throw new Error('Deduct amount must be positive.');

    const locked = await client.query(
        'SELECT balance FROM user_credits WHERE user_id = $1 FOR UPDATE',
        [userId]
    );
    if (locked.rows.length === 0) {
        const err = new Error('No credit account found for user.');
        err.status = 402;
        throw err;
    }

    const currentBalance = locked.rows[0].balance;
    if (currentBalance < amount) {
        const err = new Error(`Insufficient credits. Need ${amount}, have ${currentBalance}.`);
        err.status = 402;
        throw err;
    }

    const newBalance = currentBalance - amount;

    let ledgerId;
    try {
        const ledger = await client.query(
            `INSERT INTO credit_transactions
             (user_id, delta, balance_after, transaction_type, reference_id, description, metadata)
             VALUES ($1, $2, $3, $4, $5, $6, $7) RETURNING id`,
            [userId, -amount, newBalance, transactionType, referenceId || null, description || null, metadata ? JSON.stringify(metadata) : null]
        );
        ledgerId = ledger.rows[0].id;
    } catch (err) {
        if (err.code === '23505') {
            return { balance: currentBalance, duplicated: true };
        }
        throw err;
    }

    await client.query(
        'UPDATE user_credits SET balance = $1, updated_at = NOW() WHERE user_id = $2',
        [newBalance, userId]
    );

    return { balance: newBalance, duplicated: false, ledgerId };
}

/**
 * Read-only helpers.
 */
async function getBalance(userId) {
    const result = await db.query('SELECT balance FROM user_credits WHERE user_id = $1', [userId]);
    return result.rows.length > 0 ? result.rows[0].balance : 0;
}

async function getHistory(userId, limit = 50, offset = 0) {
    const result = await db.query(
        `SELECT id, delta, balance_after, transaction_type, reference_id, description, created_at
         FROM credit_transactions
         WHERE user_id = $1
         ORDER BY created_at DESC
         LIMIT $2 OFFSET $3`,
        [userId, limit, offset]
    );
    return result.rows;
}

module.exports = { grantCredits, deductCredits, getBalance, getHistory };