const nodemailer = require('nodemailer');

// Create transporter if SMTP credentials are provided
let transporter = null;
if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: process.env.SMTP_PORT,
        auth: {
            user: process.env.SMTP_USER,
            pass: process.env.SMTP_PASS,
        },
    });
}

const sendEmail = async (to, subject, text, html) => {
    if (!transporter) {
        console.log('--- MOCK EMAIL SENT ---');
        console.log(`To: ${to}`);
        console.log(`Subject: ${subject}`);
        console.log(`Text: ${text}`);
        console.log('-----------------------');
        return;
    }

    try {
        await transporter.sendMail({
            from: process.env.EMAIL_FROM || 'noreply@vca.com',
            to,
            subject,
            text,
            html,
        });
    } catch (error) {
        console.error('Email sending failed:', error);
        throw new Error('Failed to send email');
    }
};

const sendOTPEmail = async (email, otp) => {
    const subject = 'Your VCA AI Humanizer Verification Code';
    const text = `Your verification code is: ${otp}. It expires in 10 minutes.`;
    const html = `<p>Your verification code is: <strong>${otp}</strong></p><p>It expires in 10 minutes.</p>`;
    await sendEmail(email, subject, text, html);
};

const sendPasswordResetEmail = async (email, resetToken) => {
    const resetUrl = `${process.env.FRONTEND_URL || 'http://localhost:3000'}/reset-password.html?token=${resetToken}`;
    const subject = 'VCA AI Humanizer Password Reset';
    const text = `You requested a password reset. Click here to reset your password: ${resetUrl}. This link expires in 1 hour.`;
    const html = `<p>You requested a password reset.</p><p><a href="${resetUrl}">Click here to reset your password</a></p><p>This link expires in 1 hour.</p>`;
    await sendEmail(email, subject, text, html);
};

module.exports = { sendOTPEmail, sendPasswordResetEmail };