/**
 * Blog Writer Service
 * Builds the prompt for Ollama to generate a complete SEO-friendly blog post.
 */

function buildBlogPrompt({ title, primaryKeyword, secondaryKeywords, outline, targetWordCount, tone, language }) {
    const keywordList = [primaryKeyword, ...(secondaryKeywords || [])].join(', ');
    const outlineText = outline && outline.length > 0 
        ? `Follow this outline:\n${JSON.stringify(outline, null, 2)}` 
        : 'Create a logical outline for this topic.';

    return `You are an expert SEO content writer and journalist.
Write a highly engaging, original, and SEO-optimized blog post in ${language}.

Parameters:
- Title: "${title}"
- Target Word Count: ~${targetWordCount} words
- Tone: ${tone}
- Target Keywords to include naturally: ${keywordList}

Instructions:
1. Write a compelling introduction.
2. ${outlineText}
3. Write a strong conclusion with a call to action.
4. Include an FAQ section with 3-5 common questions based on the topic.
5. Do NOT keyword stuff. Use the primary keyword 2-3 times naturally, and secondary keywords sparingly.
6. Format the main content in Markdown (use # for H1, ## for H2, ### for H3).

You MUST respond in strict JSON format matching this exact structure:
{
  "title": "${title}",
  "slug": "url-friendly-slug",
  "metaTitle": "SEO meta title (max 60 chars)",
  "metaDescription": "SEO meta description (max 160 chars)",
  "contentMarkdown": "The full blog post in Markdown format",
  "faq": [
    { "question": "Question 1?", "answer": "Answer 1." }
  ]
}`;
}

module.exports = { buildBlogPrompt };