const { chunkText } = require('../../utils/textChunker');

/**
 * Build a prompt for the Ollama model that humanizes a chunk of text.
 */
function buildHumanizePrompt(text, language = 'en', tone = 'neutral') {
    return `You are a professional human writer. Rewrite the following AI-generated text so it reads naturally and is undetectable as AI-generated.

Rules:
- Preserve the original meaning exactly.
- Match a ${tone} tone.
- Use natural sentence variation and conversational flow.
- Do NOT add new facts or remove important information.
- Do NOT add commentary, introductions, or explanations. Only output the rewritten text.

Text to rewrite:
"""
${text}
"""

Rewritten text:`;
}

/**
 * Build the prompt for translator service as well.
 */
function buildTranslatePrompt(text, targetLanguage) {
    return `You are a professional translator. Translate the following text into ${targetLanguage}. 
Preserve the original meaning, tone, and nuance. Do NOT add commentary, introductions, or explanations. Only output the translated text.

Text to translate:
"""
${text}
"""

Translation:`;
}

/**
 * Humanize text via Ollama. Returns concatenated result across chunks.
 * The orchestrator handles caching, credits, and error tracking.
 */
async function humanize({ text, language, tone, provider, model }) {
    const chunks = chunkText(text);
    const outputs = [];
    for (const chunk of chunks) {
        const prompt = buildHumanizePrompt(chunk, language, tone);
        const result = await provider.generate(prompt, model);
        outputs.push(result);
    }
    return outputs.join('\n\n');
}

async function translate({ text, targetLanguage, provider, model }) {
    const chunks = chunkText(text);
    const outputs = [];
    for (const chunk of chunks) {
        const prompt = buildTranslatePrompt(chunk, targetLanguage);
        const result = await provider.generate(prompt, model);
        outputs.push(result);
    }
    return outputs.join('\n\n');
}

module.exports = { humanize, translate };