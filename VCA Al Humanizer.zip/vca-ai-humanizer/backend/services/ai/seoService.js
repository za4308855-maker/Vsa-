/**
 * SEO Research Service
 * Builds the prompt for Ollama to generate structured SEO insights.
 * CRITICAL: Instructs the AI NOT to invent search volumes or competition metrics.
 */

function buildSEOPrompt(topic, targetCountry, targetLanguage, depth) {
    const depthInstructions = {
        quick: "Provide a concise, high-level overview with 3-5 secondary keywords and a basic outline.",
        standard: "Provide a comprehensive analysis with 5-10 secondary keywords, detailed relevance scores, and a full content outline.",
        deep: "Provide an exhaustive analysis with 10-15 secondary keywords, detailed topic clusters, comprehensive content outlines, and deep trend insights."
    };

    return `You are an expert SEO strategist and content planner.
Analyze the following topic for the target market: ${targetCountry} in language: ${targetLanguage}.

Topic: "${topic}"
Research Depth: ${depthInstructions[depth] || depthInstructions.standard}

CRITICAL RULES:
1. You DO NOT have access to live search volume, CPC, or competition data. NEVER invent fake numbers for search volume or difficulty.
2. Base your relevance scores on semantic relevance and topical authority, NOT search volume.
3. The "trendInsights" array should contain qualitative observations about the topic's current state, not fake metrics.

You MUST respond in strict JSON format matching this exact structure:
{
  "primaryKeyword": "The single best primary keyword",
  "secondaryKeywords": ["keyword 1", "keyword 2"],
  "searchIntent": "informational | commercial | transactional | navigational",
  "metaDescription": "A compelling meta description under 160 characters.",
  "suggestedTitles": [
    { "title": "An SEO-optimized title", "reason": "Why this title works" }
  ],
  "keywordRelevance": [
    { "keyword": "keyword name", "relevance_score": 85, "reason": "Why it is relevant" }
  ],
  "topicClusters": [
    { "cluster_name": "Name", "keywords": ["kw1", "kw2"], "subtopics": ["sub1", "sub2"] }
  ],
  "contentOutline": [
    { "h2": "Main Heading", "h3s": ["Sub 1", "Sub 2"], "notes": "What to cover" }
  ],
  "trendInsights": [
    "A qualitative observation about the trend.",
    "Another observation."
  ]
}`;
}

module.exports = { buildSEOPrompt };