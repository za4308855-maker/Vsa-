const crypto = require('crypto');
const db = require('../../database');
const ollamaProvider = require('./providers/ollamaProvider');
const humanizerService = require('./humanizerService');
const seoService = require('./seoService');
const blogService = require('./blogService');
const { countWords } = require('../../utils/textChunker');
const { safeParse, validateSEOOutput, validateBlogOutput } = require('../../utils/jsonGuard');

const DEFAULT_MODEL = process.env.OLLAMA_MODEL || 'llama3';
const DEFAULT_CREDITS = parseInt(process.env.AI_DEFAULT_CREDITS || '1000', 10);
const MAX_WORDS = parseInt(process.env.AI_MAX_WORDS_PER_REQUEST || '1000', 10);

const SEO_COSTS = {
    quick: parseInt(process.env.AI_SEO_COST_QUICK || '150', 10),
    standard: parseInt(process.env.AI_SEO_COST_STANDARD || '300', 10),
    deep: parseInt(process.env.AI_SEO_COST_DEEP || '600', 10)
};
const BLOG_OVERHEAD = parseInt(process.env.AI_BLOG_OVERHEAD || '500', 10);
const BLOG_MIN_WORDS = parseInt(process.env.AI_BLOG_MIN_WORDS || '500', 10);
const BLOG_MAX_WORDS = parseInt(process.env.AI_BLOG_MAX_WORDS || '3000', 10);

function generateInputHash(userId, jobType, text, model, language, settings) {
    const raw = `${userId}|${jobType}|${text}|${model}|${language}|${JSON.stringify(settings || {})}`;
    return crypto.createHash('sha256').update(raw).digest('hex');
}

async function ensureCreditsRow(userId) {
    const existing = await db.query('SELECT balance FROM user_credits WHERE user_id = $1', [userId]);
    if (existing.rows.length > 0) return existing.rows[0].balance;
    const inserted = await db.query(
        'INSERT INTO user_credits (user_id, balance) VALUES ($1, $2) ON CONFLICT (user_id) DO NOTHING RETURNING balance',
        [userId, DEFAULT_CREDITS]
    );
    if (inserted.rows.length > 0) return inserted.rows[0].balance;
    const retry = await db.query('SELECT balance FROM user_credits WHERE user_id = $1', [userId]);
    return retry.rows[0]?.balance || 0;
}

function createError(status, message) {
    const err = new Error(message);
    err.status = status;
    return err;
}

/**
 * PHASE 6 HELPER: Deduct credits + write to ledger in one atomic statement pair.
 * Idempotent via UNIQUE(user_id, reference_id, transaction_type).
 * Must be called inside an open transaction with the user_credits row already locked.
 */
async function writeCreditDeduction(client, { userId, amount, jobId, jobType, description }) {
    const updated = await client.query(
        'UPDATE user_credits SET balance = balance - $1, updated_at = NOW() WHERE user_id = $2 RETURNING balance',
        [amount, userId]
    );
    const balanceAfter = updated.rows[0].balance;
    await client.query(
        `INSERT INTO credit_transactions (user_id, delta, balance_after, transaction_type, reference_id, description)
         VALUES ($1, $2, $3, 'ai_usage', $4, $5)
         ON CONFLICT (user_id, reference_id, transaction_type) DO NOTHING`,
        [userId, -amount, balanceAfter, `ai_job:${jobId}`, description || `${jobType} usage`]
    );
    return balanceAfter;
}

// --- Phase 4: Humanize & Translate ---
async function processJob({ userId, jobType, text, language = 'en', tone = 'neutral', settings = {} }) {
    if (!text || text.trim() === '') throw createError(400, 'Text is required.');
    if (countWords(text) > MAX_WORDS) throw createError(400, `Text exceeds maximum of ${MAX_WORDS} words.`);

    const modelName = DEFAULT_MODEL;
    const inputHash = generateInputHash(userId, jobType, text.trim(), modelName, language, { tone, ...settings });

    const cached = await db.query(
        "SELECT output_text FROM ai_jobs WHERE user_id = $1 AND input_hash = $2 AND status = 'completed' LIMIT 1",
        [userId, inputHash]
    );
    if (cached.rows.length > 0 && cached.rows[0].output_text) {
        return { output: cached.rows[0].output_text, cached: true, wordCount: countWords(text), model: modelName };
    }

    const wordCount = countWords(text);
    const balance = await ensureCreditsRow(userId);
    if (balance < wordCount) throw createError(402, `Insufficient credits. Need ${wordCount}, have ${balance}.`);

    const insert = await db.query(
        `INSERT INTO ai_jobs (user_id, input_hash, model_name, job_type, status) VALUES ($1, $2, $3, $4, 'processing') RETURNING id`,
        [userId, inputHash, modelName, jobType]
    );
    const jobId = insert.rows[0].id;

    const startTime = Date.now();
    let output;
    try {
        if (jobType === 'humanize') {
            output = await humanizerService.humanize({ text, language, tone, provider: ollamaProvider, model: modelName });
        } else if (jobType === 'translate') {
            output = await humanizerService.translate({ text, targetLanguage: language, provider: ollamaProvider, model: modelName });
        }
    } catch (err) {
        await db.query("UPDATE ai_jobs SET status = 'failed' WHERE id = $1", [jobId]);
        throw createError(err.code === 'AI_UNREACHABLE' ? 503 : 500, err.message);
    }

    const processingTime = Date.now() - startTime;
    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');
        const locked = await client.query('SELECT balance FROM user_credits WHERE user_id = $1 FOR UPDATE', [userId]);
        if (locked.rows[0].balance < wordCount) {
            await client.query("UPDATE ai_jobs SET status = 'failed' WHERE id = $1", [jobId]);
            await client.query('ROLLBACK');
            throw createError(402, 'Insufficient credits at time of deduction.');
        }
        await writeCreditDeduction(client, { userId, amount: wordCount, jobId, jobType });
        await client.query("UPDATE ai_jobs SET status = 'completed', output_text = $1, processing_time = $2 WHERE id = $3", [output, processingTime, jobId]);
        await client.query('COMMIT');
    } catch (err) {
        await client.query('ROLLBACK');
        throw err;
    } finally {
        client.release();
    }

    return { output, cached: false, wordCount, model: modelName, processingTime };
}

// --- Phase 5: SEO Research ---
async function processSEOJob({ userId, topic, targetCountry = 'US', targetLanguage = 'en', researchDepth = 'standard' }) {
    if (!topic || topic.trim().length < 3) throw createError(400, 'Topic must be at least 3 characters.');

    const modelName = DEFAULT_MODEL;
    const cost = SEO_COSTS[researchDepth] || SEO_COSTS.standard;
    const inputHash = generateInputHash(userId, 'seo', topic.trim(), modelName, targetLanguage, { country: targetCountry, depth: researchDepth });

    const cached = await db.query(
        "SELECT output_text FROM ai_jobs WHERE user_id = $1 AND input_hash = $2 AND status = 'completed' LIMIT 1",
        [userId, inputHash]
    );
    if (cached.rows.length > 0 && cached.rows[0].output_text) {
        const researchRow = await db.query("SELECT * FROM seo_research WHERE user_id = $1 AND job_id = (SELECT id FROM ai_jobs WHERE input_hash = $2 AND status = 'completed' LIMIT 1)", [userId, inputHash]);
        return { output: JSON.parse(cached.rows[0].output_text), researchId: researchRow.rows[0]?.id, cached: true, processingTime: 0, creditsUsed: 0 };
    }

    const balance = await ensureCreditsRow(userId);
    if (balance < cost) throw createError(402, `Insufficient credits for SEO research. Need ${cost}, have ${balance}.`);

    const insert = await db.query(
        `INSERT INTO ai_jobs (user_id, input_hash, model_name, job_type, status) VALUES ($1, $2, $3, 'seo_research', 'processing') RETURNING id`,
        [userId, inputHash, modelName]
    );
    const jobId = insert.rows[0].id;

    const startTime = Date.now();
    let validatedOutput;
    try {
        const prompt = seoService.buildSEOPrompt(topic, targetCountry, targetLanguage, researchDepth);
        const raw = await ollamaProvider.generate(prompt, modelName, 'json');
        validatedOutput = validateSEOOutput(safeParse(raw));
    } catch (err) {
        await db.query("UPDATE ai_jobs SET status = 'failed' WHERE id = $1", [jobId]);
        const status = err.code === 'AI_UNREACHABLE' ? 503 : err.code === 'AI_INVALID_OUTPUT' ? 502 : 500;
        throw createError(status, err.message);
    }

    const processingTime = Date.now() - startTime;
    const client = await db.pool.connect();
    let researchId;
    try {
        await client.query('BEGIN');
        const locked = await client.query('SELECT balance FROM user_credits WHERE user_id = $1 FOR UPDATE', [userId]);
        if (locked.rows[0].balance < cost) {
            await client.query("UPDATE ai_jobs SET status = 'failed' WHERE id = $1", [jobId]);
            await client.query('ROLLBACK');
            throw createError(402, 'Insufficient credits at time of deduction.');
        }

        await writeCreditDeduction(client, { userId, amount: cost, jobId, jobType: 'seo_research', description: `SEO research (${researchDepth})` });

        await client.query(
            "UPDATE ai_jobs SET status = 'completed', output_text = $1, processing_time = $2 WHERE id = $3",
            [JSON.stringify(validatedOutput), processingTime, jobId]
        );

        const researchInsert = await client.query(
            `INSERT INTO seo_research (
                user_id, job_id, topic, target_country, target_language, research_depth,
                primary_keyword, secondary_keywords, search_intent, keyword_relevance,
                suggested_titles, meta_description, topic_clusters, content_outline, trend_insights
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING id`,
            [
                userId, jobId, topic, targetCountry, targetLanguage, researchDepth,
                validatedOutput.primaryKeyword, JSON.stringify(validatedOutput.secondaryKeywords),
                validatedOutput.searchIntent, JSON.stringify(validatedOutput.keywordRelevance),
                JSON.stringify(validatedOutput.suggestedTitles), validatedOutput.metaDescription,
                JSON.stringify(validatedOutput.topicClusters), JSON.stringify(validatedOutput.contentOutline),
                JSON.stringify(validatedOutput.trendInsights)
            ]
        );
        researchId = researchInsert.rows[0].id;
        await client.query('COMMIT');
    } catch (err) {
        await client.query('ROLLBACK');
        throw err;
    } finally {
        client.release();
    }

    return { output: validatedOutput, researchId, cached: false, processingTime, creditsUsed: cost };
}

// --- Phase 5: Blog Generation ---
async function processBlogJob({ userId, seoResearchId, title, primaryKeyword, secondaryKeywords, targetWordCount, tone, language }) {
    if (targetWordCount < BLOG_MIN_WORDS || targetWordCount > BLOG_MAX_WORDS) {
        throw createError(400, `Word count must be between ${BLOG_MIN_WORDS} and ${BLOG_MAX_WORDS}.`);
    }
    if (!title || title.trim() === '') throw createError(400, 'Title is required.');

    let outline = null;
    let resolvedPrimaryKeyword = primaryKeyword;
    let resolvedSecondaryKeywords = secondaryKeywords || [];

    if (seoResearchId) {
        const research = await db.query('SELECT * FROM seo_research WHERE id = $1 AND user_id = $2', [seoResearchId, userId]);
        if (research.rows.length === 0) throw createError(404, 'SEO research not found or unauthorized.');
        const r = research.rows[0];
        resolvedPrimaryKeyword = r.primary_keyword;
        resolvedSecondaryKeywords = r.secondary_keywords || [];
        outline = r.content_outline || [];
        if (!title) title = r.suggested_titles?.[0]?.title || r.topic;
    }

    if (!resolvedPrimaryKeyword) throw createError(400, 'Primary keyword is required.');

    const modelName = DEFAULT_MODEL;
    const cost = targetWordCount + BLOG_OVERHEAD;
    const inputHash = generateInputHash(userId, 'blog', title.trim(), modelName, language, {
        wordCount: targetWordCount, tone, keywords: resolvedSecondaryKeywords, nonce: Date.now()
    });

    const balance = await ensureCreditsRow(userId);
    if (balance < cost) throw createError(402, `Insufficient credits for blog generation. Need ${cost}, have ${balance}.`);

    const insert = await db.query(
        `INSERT INTO ai_jobs (user_id, input_hash, model_name, job_type, status) VALUES ($1, $2, $3, 'blog_generate', 'processing') RETURNING id`,
        [userId, inputHash, modelName]
    );
    const jobId = insert.rows[0].id;

    const startTime = Date.now();
    let validatedOutput;
    try {
        const prompt = blogService.buildBlogPrompt({
            title, primaryKeyword: resolvedPrimaryKeyword, secondaryKeywords: resolvedSecondaryKeywords,
            outline, targetWordCount, tone, language
        });
        const raw = await ollamaProvider.generate(prompt, modelName, 'json');
        validatedOutput = validateBlogOutput(safeParse(raw), targetWordCount);
    } catch (err) {
        await db.query("UPDATE ai_jobs SET status = 'failed' WHERE id = $1", [jobId]);
        const status = err.code === 'AI_UNREACHABLE' ? 503 : err.code === 'AI_INVALID_OUTPUT' ? 502 : 500;
        throw createError(status, err.message);
    }

    const processingTime = Date.now() - startTime;
    const client = await db.pool.connect();
    let draftId;
    try {
        await client.query('BEGIN');
        const locked = await client.query('SELECT balance FROM user_credits WHERE user_id = $1 FOR UPDATE', [userId]);
        if (locked.rows[0].balance < cost) {
            await client.query("UPDATE ai_jobs SET status = 'failed' WHERE id = $1", [jobId]);
            await client.query('ROLLBACK');
            throw createError(402, 'Insufficient credits at time of deduction.');
        }

        await writeCreditDeduction(client, { userId, amount: cost, jobId, jobType: 'blog_generate', description: `Blog generation (${targetWordCount} words)` });

        await client.query(
            "UPDATE ai_jobs SET status = 'completed', output_text = $1, processing_time = $2 WHERE id = $3",
            [JSON.stringify(validatedOutput), processingTime, jobId]
        );

        const draftInsert = await client.query(
            `INSERT INTO blog_drafts (
                user_id, job_id, seo_research_id, title, slug, meta_title, meta_description,
                content_markdown, faq, target_word_count, actual_word_count, tone, language,
                primary_keyword, secondary_keywords
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15) RETURNING id`,
            [
                userId, jobId, seoResearchId || null, validatedOutput.title, validatedOutput.slug,
                validatedOutput.metaTitle, validatedOutput.metaDescription, validatedOutput.contentMarkdown,
                JSON.stringify(validatedOutput.faq), targetWordCount, validatedOutput.actualWordCount,
                tone, language, resolvedPrimaryKeyword, JSON.stringify(resolvedSecondaryKeywords)
            ]
        );
        draftId = draftInsert.rows[0].id;
        await client.query('COMMIT');
    } catch (err) {
        await client.query('ROLLBACK');
        throw err;
    } finally {
        client.release();
    }

    return { output: validatedOutput, draftId, cached: false, processingTime, creditsUsed: cost };
}

module.exports = { processJob, processSEOJob, processBlogJob };