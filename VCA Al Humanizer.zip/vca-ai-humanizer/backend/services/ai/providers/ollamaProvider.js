/**
 * Ollama Provider (Phase 5 - updated with JSON mode support).
 * Existing humanizer/translator calls are unaffected: format defaults to null.
 */

const OLLAMA_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const DEFAULT_MODEL = process.env.OLLAMA_MODEL || 'llama3';
const TIMEOUT_MS = parseInt(process.env.AI_REQUEST_TIMEOUT_MS || '60000', 10);

/**
 * Send a prompt to Ollama.
 * @param {string} prompt
 * @param {string} modelName
 * @param {string|null} format - 'json' to force JSON output; null for default text
 */
async function generate(prompt, modelName = DEFAULT_MODEL, format = null) {
    const controller = new AbortController();
    const timeoutHandle = setTimeout(() => controller.abort(), TIMEOUT_MS);

    const body = {
        model: modelName,
        prompt: prompt,
        stream: false,
    };
    if (format) body.format = format;

    try {
        const response = await fetch(`${OLLAMA_URL}/api/generate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            signal: controller.signal,
        });

        clearTimeout(timeoutHandle);

        if (!response.ok) {
            const errText = await response.text().catch(() => 'unknown error');
            throw new Error(`Ollama returned ${response.status}: ${errText}`);
        }

        const data = await response.json();
        if (!data.response) {
            throw new Error('Ollama returned an empty response.');
        }
        return data.response.trim();
    } catch (err) {
        clearTimeout(timeoutHandle);

        if (err.name === 'AbortError') {
            const timeoutErr = new Error(`AI request timed out after ${TIMEOUT_MS}ms`);
            timeoutErr.code = 'AI_TIMEOUT';
            throw timeoutErr;
        }
        if (err.cause && err.cause.code === 'ECONNREFUSED') {
            const connErr = new Error(
                `Cannot connect to Ollama at ${OLLAMA_URL}. Ensure Ollama is running (ollama serve) and the model "${modelName}" has been pulled.`
            );
            connErr.code = 'AI_UNREACHABLE';
            throw connErr;
        }
        throw err;
    }
}

module.exports = { generate };

async function generate(prompt, modelName, format) {
    try {
        const response = await fetch(`${OLLAMA_URL}/api/generate`, { /* ... */ });
        if (!response.ok) {
            throw new Error(`Ollama returned ${response.status}`);
        }
        return data.response;
    } catch (err) {
        const error = new Error('AI Provider Unavailable. Check if Ollama is running.');
        error.status = 503; // Service Unavailable
        throw error;
    }
}