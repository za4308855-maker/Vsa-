const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');

const hashPassword = async (password) => {
    const salt = await bcrypt.genSalt(12);
    return await bcrypt.hash(password, salt);
};

const comparePassword = async (password, hash) => {
    return await bcrypt.compare(password, hash);
};

const generateOTP = () => {
    // Generate a 6-digit numeric OTP
    return Math.floor(100000 + Math.random() * 900000).toString();
};

const hashToken = (token) => {
    // Use SHA-256 for OTPs and Reset Tokens (they are high-entropy or short-lived)
    return crypto.createHash('sha256').update(token).digest('hex');
};

const generateJWT = (userId) => {
    return jwt.sign({ id: userId }, process.env.JWT_SECRET || 'fallback_secret', {
        expiresIn: '7d',
    });
};

module.exports = {
    hashPassword,
    comparePassword,
    generateOTP,
    hashToken,
    generateJWT
};