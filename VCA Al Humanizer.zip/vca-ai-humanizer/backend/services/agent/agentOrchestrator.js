const db = require('../../database');

// Provider Interfaces (Native Fetch to avoid heavy SDK dependencies)
const providers = {
    openai: async (apiKey, model, prompt) => {
        const res = await fetch('https://api.openai.com/v1/chat/completions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
            body: JSON.stringify({ model, messages: [{ role: 'user', content: prompt }] })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error?.message || 'OpenAI API Error');
        return { text: data.choices[0].message.content, tokens: data.usage.total_tokens };
    },
    gemini: async (apiKey, model, prompt) => {
        const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error?.message || 'Gemini API Error');
        return { text: data.candidates[0].content.parts[0].text, tokens: data.usageMetadata.totalTokenCount };
    }
};

exports.generate = async (userId, prompt) => {
    // 1. Get Config
    const settings = await db.query("SELECT key, value FROM website_settings WHERE key IN ('ai_agent_provider', 'ai_agent_model')");
    const config = settings.rows.reduce((acc, row) => ({ ...acc, [row.key]: row.value }), {});
    
    const providerName = config.ai_agent_provider || 'openai';
    const model = config.ai_agent_model || 'gpt-4o-mini';
    const apiKey = providerName === 'openai' ? process.env.OPENAI_API_KEY : process.env.GEMINI_API_KEY;

    if (!apiKey) {
        throw Object.assign(new Error(`${providerName.toUpperCase()}_API_KEY is not configured in .env`), { status: 503 });
    }

    // 2. Call Provider
    const result = await providers[providerName](apiKey, model, prompt);

    // 3. Log Usage
    await db.query(
        'INSERT INTO agent_usage_logs (user_id, provider, model, prompt_tokens) VALUES ($1, $2, $3, $4)',
        [userId, providerName, model, result.tokens]
    );

    return { text: result.text, provider: providerName, model };
};

exports.testConnection = async (providerName, model) => {
    const apiKey = providerName === 'openai' ? process.env.OPENAI_API_KEY : process.env.GEMINI_API_KEY;
    if (!apiKey) throw new Error(`${providerName.toUpperCase()}_API_KEY is not configured.`);
    
    await providers[providerName](apiKey, model, 'Respond with exactly: "Connection successful"');
    return true;
};