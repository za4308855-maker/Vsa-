const jwt = require('jsonwebtoken');
const db = require('../database');

const protect = async (req, res, next) => {
    let token = req.cookies.jwt;

    if (!token) {
        return res.status(401).json({ status: 'error', message: 'Not authorized, no token' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');
        
        // Phase 7: Verify the user still exists and is not suspended
        const user = await db.query('SELECT status, is_admin FROM users WHERE id = $1', [decoded.id]);
        if (user.rows.length === 0) {
            return res.status(401).json({ status: 'error', message: 'User no longer exists' });
        }
        if (user.rows[0].status === 'suspended') {
            return res.status(403).json({ status: 'error', message: 'Account suspended. Please contact support.' });
        }

        req.user = decoded;
        req.user.is_admin = user.rows[0].is_admin; // Attach for convenience
        next();
    } catch (error) {
        res.status(401).json({ status: 'error', message: 'Not authorized, token failed' });
    }
};

module.exports = { protect };