const db = require('../database');

/**
 * Requires the user to have is_admin = TRUE in the database.
 * Must be used AFTER the `protect` middleware.
 */
async function requireAdmin(req, res, next) {
    try {
        if (!req.user || !req.user.id) {
            return res.status(401).json({ status: 'error', message: 'Authentication required.' });
        }
        const result = await db.query('SELECT is_admin FROM users WHERE id = $1', [req.user.id]);
        if (result.rows.length === 0 || !result.rows[0].is_admin) {
            return res.status(403).json({ status: 'error', message: 'Admin access required.' });
        }
        next();
    } catch (err) {
        next(err);
    }
}

module.exports = { requireAdmin };