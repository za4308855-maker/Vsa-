const rateLimit = require('express-rate-limit');

// 1. Auth Limiter (Strict)
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 mins
    max: 10,
    message: { status: 'error', message: 'Too many authentication attempts. Please try again after 15 minutes.' }
});

// 2. Global API Limiter (Prevents general abuse)
const globalLimiter = rateLimit({
    windowMs: 1 * 60 * 1000, // 1 min
    max: 100, // Limit each IP to 100 requests per minute
    message: { status: 'error', message: 'Too many requests from this IP. Please try again later.' }
});

// 3. AI Limiter (Expensive operations)
const aiLimiter = rateLimit({
    windowMs: 1 * 60 * 1000,
    max: 5,
    message: { status: 'error', message: 'Too many AI requests. Please wait a minute.' }
});

// 4. SEO/Blog Limiters
const seoLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 3,
    message: { status: 'error', message: 'SEO research limit reached (3 per hour).' }
});

const blogLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 2,
    message: { status: 'error', message: 'Blog generation limit reached (2 per hour).' }
});

module.exports = { authLimiter, globalLimiter, aiLimiter, seoLimiter, blogLimiter };