const { Pool } = require('pg');
require('dotenv').config();

// Setup PostgreSQL connection pool using environment variables
// Credentials are NEVER exposed to the frontend.
const pool = new Pool({
    user: process.env.DB_USER,
    host: process.env.DB_HOST,
    database: process.env.DB_NAME,
    password: process.env.DB_PASSWORD,
    port: process.env.DB_PORT || 5432,
    // Timeout after 5 seconds if DB is unreachable to prevent hanging requests
    connectionTimeoutMillis: 5000 
});

// Log connection errors on the pool
pool.on('error', (err) => {
    console.error('Unexpected error on idle PostgreSQL client', err);
});

module.exports = {
    query: (text, params) => pool.query(text, params),
    pool
};