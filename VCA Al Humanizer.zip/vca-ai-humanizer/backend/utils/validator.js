/**
 * Lightweight validation utility to prevent malformed data from reaching
 * the database or the AI engine. Prevents SQL injection payloads and XSS vectors.
 */

const isValidEmail = (email) => {
    if (typeof email !== 'string') return false;
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email) && email.length < 255;
};

const isValidString = (str, min = 1, max = 5000) => {
    return typeof str === 'string' && str.trim().length >= min && str.length <= max;
};

const isStrongPassword = (password) => {
    // Min 8 chars. Add more complexity requirements here if needed.
    return typeof password === 'string' && password.length >= 8;
};

// Middleware factory for validating request bodies
const validateBody = (rules) => {
    return (req, res, next) => {
        const errors = [];
        for (const [field, rule] of Object.entries(rules)) {
            const value = req.body[field];
            
            if (rule.required && (value === undefined || value === null || value === '')) {
                errors.push(`${field} is required.`);
                continue;
            }
            if (value && rule.type === 'email' && !isValidEmail(value)) {
                errors.push(`${field} must be a valid email.`);
            }
            if (value && rule.type === 'string' && !isValidString(value, rule.min, rule.max)) {
                errors.push(`${field} must be between ${rule.min || 1} and ${rule.max || 5000} characters.`);
            }
            if (value && rule.type === 'password' && !isStrongPassword(value)) {
                errors.push(`${field} must be at least 8 characters long.`);
            }
        }

        if (errors.length > 0) {
            return res.status(400).json({ status: 'error', message: errors[0], errors });
        }
        next();
    };
};

module.exports = { validateBody };