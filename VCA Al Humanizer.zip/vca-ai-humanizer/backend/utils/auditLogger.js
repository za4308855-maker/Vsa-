const db = require('../database');

/**
 * Log a sensitive admin action.
 * Fire-and-forget (does not block the API response), but logs errors to console.
 */
async function logAdminAction({ adminId, action, targetType, targetId, details, req }) {
    try {
        const ipAddress = req ? (req.headers['x-forwarded-for'] || req.socket.remoteAddress) : null;
        await db.query(
            `INSERT INTO audit_logs (admin_id, action, target_type, target_id, details, ip_address)
             VALUES ($1, $2, $3, $4, $5, $6)`,
            [adminId, action, targetType || null, targetId ? String(targetId) : null, details ? JSON.stringify(details) : null, ipAddress]
        );
    } catch (err) {
        console.error('[AuditLogger] Failed to write audit log:', err.message);
    }
}

module.exports = { logAdminAction };