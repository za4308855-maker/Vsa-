/**
 * JSON Guard - validates LLM JSON output against expected schemas.
 * Ollama's format='json' guarantees valid JSON syntax, but not schema compliance.
 * If critical fields are missing, we throw to avoid charging users for bad output.
 */

function safeParse(rawText) {
    if (!rawText) return null;
    try {
        // Ollama sometimes wraps JSON in ```json fences despite format='json'
        const cleaned = rawText
            .replace(/^```(?:json)?\s*/i, '')
            .replace(/```\s*$/, '')
            .trim();
        return JSON.parse(cleaned);
    } catch {
        return null;
    }
}

function toArray(v) {
    return Array.isArray(v) ? v : [];
}

function toStringOrNull(v) {
    return typeof v === 'string' && v.trim() ? v.trim() : null;
}

function validateSEOOutput(parsed) {
    if (!parsed || typeof parsed !== 'object') {
        throw createInvalid('AI returned non-object JSON.');
    }
    const primaryKeyword = toStringOrNull(parsed.primaryKeyword);
    const searchIntent = toStringOrNull(parsed.searchIntent);
    const metaDescription = toStringOrNull(parsed.metaDescription);
    const suggestedTitles = toArray(parsed.suggestedTitles);

    if (!primaryKeyword) throw createInvalid('Missing primaryKeyword.');
    if (!searchIntent) throw createInvalid('Missing searchIntent.');
    if (!metaDescription) throw createInvalid('Missing metaDescription.');
    if (suggestedTitles.length === 0) throw createInvalid('Missing suggestedTitles.');

    // Normalize
    return {
        primaryKeyword,
        secondaryKeywords: toArray(parsed.secondaryKeywords).filter(k => typeof k === 'string'),
        searchIntent,
        metaDescription,
        suggestedTitles: suggestedTitles.map(t => 
            typeof t === 'string' ? { title: t, reason: '' } : 
            { title: String(t.title || ''), reason: String(t.reason || '') }
        ).filter(t => t.title),
        keywordRelevance: toArray(parsed.keywordRelevance).map(k => ({
            keyword: String(k.keyword || ''),
            relevance_score: Number(k.relevance_score || 0),
            reason: String(k.reason || '')
        })).filter(k => k.keyword),
        topicClusters: toArray(parsed.topicClusters),
        contentOutline: toArray(parsed.contentOutline),
        trendInsights: toArray(parsed.trendInsights).filter(t => typeof t === 'string')
    };
}

function validateBlogOutput(parsed, expectedWords = null) {
    if (!parsed || typeof parsed !== 'object') {
        throw createInvalid('AI returned non-object JSON.');
    }
    const title = toStringOrNull(parsed.title);
    const contentMarkdown = toStringOrNull(parsed.contentMarkdown);
    const metaDescription = toStringOrNull(parsed.metaDescription);

    if (!title) throw createInvalid('Missing title.');
    if (!contentMarkdown) throw createInvalid('Missing contentMarkdown.');
    if (!metaDescription) throw createInvalid('Missing metaDescription.');

    // Word count check (very short content = failed generation)
    const actualWords = contentMarkdown.trim().split(/\s+/).length;
    const minWords = Math.floor((expectedWords || 500) * 0.5); // Allow 50% of target
    if (actualWords < minWords) {
        throw createInvalid(`Blog content too short (${actualWords} words vs target ${expectedWords}).`);
    }

    return {
        title,
        slug: toStringOrNull(parsed.slug),
        metaTitle: toStringOrNull(parsed.metaTitle),
        metaDescription,
        contentMarkdown,
        faq: toArray(parsed.faq).map(f => ({
            question: String(f.question || ''),
            answer: String(f.answer || '')
        })).filter(f => f.question && f.answer),
        actualWordCount: actualWords
    };
}

function createInvalid(message) {
    const err = new Error(message);
    err.code = 'AI_INVALID_OUTPUT';
    return err;
}

module.exports = { safeParse, validateSEOOutput, validateBlogOutput };