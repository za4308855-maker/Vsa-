/**
 * Splits text into chunks that fit within Ollama's context window.
 * Ollama's default context varies by model, but ~500 words is universally safe.
 */
const chunkText = (text, maxWordsPerChunk = 500) => {
    if (!text || text.trim() === '') return [];
    
    const words = text.trim().split(/\s+/);
    if (words.length <= maxWordsPerChunk) {
        return [text.trim()];
    }
    
    const chunks = [];
    for (let i = 0; i < words.length; i += maxWordsPerChunk) {
        chunks.push(words.slice(i, i + maxWordsPerChunk).join(' '));
    }
    return chunks;
};

const countWords = (text) => {
    if (!text || text.trim() === '') return 0;
    return text.trim().split(/\s+/).length;
};

module.exports = { chunkText, countWords };