require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./database');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({ origin: 'http://localhost:3000', credentials: true }));
app.use(express.json());

// Serve static files
const frontendPath = path.join(__dirname, '../frontend');
app.use(express.static(frontendPath));

// --- DIRECT API ROUTE (Guarantees no 404) ---
app.get('/api/subscription/plans', async (req, res) => {
    try {
        const result = await db.query(
            `SELECT id, name, slug, description, price_monthly, price_yearly, included_credits 
             FROM subscription_plans 
             WHERE is_active = TRUE 
             ORDER BY sort_order ASC`
        );
        res.json({ status: 'success', data: result.rows });
    } catch (err) {
        console.error("Database Error:", err.message);
        res.status(500).json({ status: 'error', message: 'Database error. Check if table exists.' });
    }
});

// Frontend Catch-all
app.get('*', (req, res) => {
    if (!req.path.startsWith('/api')) {
        res.sendFile(path.join(frontendPath, 'index.html'));
    } else {
        res.status(404).json({ status: 'error', message: 'API Route not found' });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});