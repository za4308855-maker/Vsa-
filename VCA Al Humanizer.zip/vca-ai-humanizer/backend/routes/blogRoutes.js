const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const { blogLimiter } = require('../middlewares/rateLimiter');
const blogController = require('../controllers/blogController');

// All Blog routes require authentication
router.use(protect);

// Generation (Rate Limited: 2/hr)
router.post('/generate', blogLimiter, blogController.generateBlog);

// CRUD (Standard limits)
router.get('/drafts', blogController.listDrafts);
router.get('/drafts/:id', blogController.getDraft);
router.put('/drafts/:id', blogController.updateDraft);
router.delete('/drafts/:id', blogController.deleteDraft);

module.exports = router;