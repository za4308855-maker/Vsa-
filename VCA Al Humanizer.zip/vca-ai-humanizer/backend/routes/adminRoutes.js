const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const { requireAdmin } = require('../middlewares/adminMiddleware');
const { validateBody } = require('../utils/validator');

// Import Controllers
const dashboardController = require('../controllers/admin/dashboardController');
const userController = require('../controllers/admin/userController');
const aiController = require('../controllers/admin/aiController');
const billingController = require('../controllers/admin/billingController');
const contentController = require('../controllers/admin/contentController');
const settingsController = require('../controllers/admin/settingsController');
const manualPaymentAdminRoutes = require('./admin/manualPaymentAdminRoutes');

// All routes require authentication + admin privileges
router.use(protect, requireAdmin);

// Dashboard
router.get('/dashboard/stats', dashboardController.getStats);

// User Management
router.get('/users', userController.listUsers);
router.get('/users/:id', userController.getUserDetails);
router.put('/users/:id/status', 
    validateBody({ status: { required: true, type: 'string' } }), 
    userController.updateUserStatus
);

// AI Management
router.get('/ai/status', aiController.getOllamaStatus);
router.get('/ai/jobs', aiController.listJobs);
router.get('/ai/settings', aiController.getSettings);

// Billing Management (Stripe/Phase 6)
router.get('/billing/transactions', billingController.listTransactions);
router.get('/billing/plans', billingController.listPlans);
router.put('/billing/plans/:id', 
    validateBody({ 
        price_monthly: { required: false, type: 'string' },
        price_yearly: { required: false, type: 'string' },
        included_credits: { required: false, type: 'string' }
    }), 
    billingController.updatePlan
);

// Phase 9: Manual Payments & QRs
router.use('/manual-payments', manualPaymentAdminRoutes);

// Content Management
router.get('/content/seo', contentController.listSEO);
router.get('/content/blogs', contentController.listBlogs);
router.put('/content/blogs/:id/status', 
    validateBody({ status: { required: true, type: 'string' } }), 
    contentController.updateBlogStatus
);

// Website Settings & Audit Logs
router.get('/settings', settingsController.getSettings);
router.put('/settings', settingsController.updateSettings);

module.exports = router;

const assetRoutes = require('./admin/assetRoutes');
// ... inside the router.use(protect, requireAdmin) block:
router.use('/assets', assetRoutes);