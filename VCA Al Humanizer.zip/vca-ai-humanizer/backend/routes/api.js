const express = require('express');
const router = express.Router();

// Health check endpoint
router.get('/health', (req, res) => res.json({ status: 'success', message: 'API is healthy' }));

// Subscription Routes
router.use('/subscription', require('./subscriptionRoutes'));

// Add your other routes here (Auth, AI, SEO, Blog, Admin)
// router.use('/auth', require('./authRoutes'));
// router.use('/admin', require('./adminRoutes'));

module.exports = router;