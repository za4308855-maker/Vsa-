const express = require('express');
const router = express.Router();
const subscriptionController = require('../controllers/subscriptionController');

router.get('/plans', subscriptionController.listPlans);

module.exports = router;