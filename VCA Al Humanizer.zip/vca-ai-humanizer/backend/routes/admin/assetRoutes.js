const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const assetController = require('../../controllers/admin/assetController');

const ASSET_DIR = path.join(__dirname, '../../../frontend/public/assets');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const category = req.body.category || 'images';
        const dir = path.join(ASSET_DIR, category);
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        cb(null, dir);
    },
    filename: (req, file, cb) => {
        const ext = path.extname(file.originalname).toLowerCase();
        const uniqueSuffix = crypto.randomBytes(8).toString('hex');
        cb(null, `${Date.now()}-${uniqueSuffix}${ext}`);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 5 * 1024 * 1024 },
    fileFilter: (req, file, cb) => {
        const allowed = ['image/jpeg', 'image/png', 'image/svg+xml', 'image/x-icon'];
        if (allowed.includes(file.mimetype)) cb(null, true);
        else cb(new Error('Invalid file type. Only JPG, PNG, SVG, ICO allowed.'));
    }
});

router.get('/', assetController.listAssets);
router.post('/upload', upload.single('asset'), assetController.uploadAsset);
router.delete('/:category/:filename', assetController.deleteAsset);

module.exports = router;