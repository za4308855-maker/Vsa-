const express = require('express');
const router = express.Router();
const manualPaymentController = require('../../controllers/admin/manualPaymentController');
const upload = require('../../utils/fileUpload');

// Orders
router.get('/orders', manualPaymentController.listOrders);
router.get('/orders/:orderId/screenshot', manualPaymentController.getScreenshot);
router.post('/orders/:orderId/approve', manualPaymentController.approveOrder);
router.post('/orders/:orderId/reject', manualPaymentController.rejectOrder);

// QR Codes
router.get('/qrs', manualPaymentController.getQRCodes);
router.post('/qrs/:slot', upload.single('qr_image'), manualPaymentController.uploadQRCode);
router.put('/qrs/:slot/toggle', manualPaymentController.toggleQRCode);

module.exports = router;