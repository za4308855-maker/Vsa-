const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const manualPaymentController = require('../controllers/manualPaymentController');
const upload = require('../utils/fileUpload');

// All routes require authentication
router.use(protect);

router.post('/create-order', manualPaymentController.createOrder);
router.post('/submit-payment', upload.single('screenshot'), manualPaymentController.submitPayment);

module.exports = router;