const express = require('express');
const router = express.Router();
const rateLimit = require('express-rate-limit');
const { protect } = require('../middlewares/authMiddleware');
const aiController = require('../controllers/aiController');

// Stricter rate limiter for AI endpoints (expensive)
const aiLimiter = rateLimit({
    windowMs: 60 * 1000, // 1 minute
    max: 5,
    message: {
        status: 'error',
        message: 'Too many AI requests. Please wait a minute before trying again.'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// All AI routes require authentication + rate limiting
router.post('/humanize', protect, aiLimiter, aiController.humanize);
router.post('/translate', protect, aiLimiter, aiController.translate);

module.exports = router;