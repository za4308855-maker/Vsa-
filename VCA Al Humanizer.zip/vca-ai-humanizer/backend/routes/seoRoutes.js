const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const { seoLimiter } = require('../middlewares/rateLimiter');
const seoController = require('../controllers/seoController');

// All SEO routes require authentication
router.use(protect);

// Generation (Rate Limited: 3/hr)
router.post('/research', seoLimiter, seoController.startResearch);

// CRUD (Standard limits)
router.get('/research', seoController.listResearch);
router.get('/research/:id', seoController.getResearch);
router.delete('/research/:id', seoController.deleteResearch);

module.exports = router;