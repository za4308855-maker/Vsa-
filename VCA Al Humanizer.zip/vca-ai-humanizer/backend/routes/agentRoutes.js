const express = require('express');
const router = express.Router();
const { protect } = require('../middlewares/authMiddleware');
const agentOrchestrator = require('../services/agent/agentOrchestrator');

router.use(protect);

router.post('/chat', async (req, res, next) => {
    try {
        const { prompt } = req.body;
        if (!prompt || prompt.length < 2) {
            return res.status(400).json({ status: 'error', message: 'Valid prompt required.' });
        }
        const result = await agentOrchestrator.generate(req.user.id, prompt);
        res.status(200).json({ status: 'success', data: result });
    } catch (err) {
        res.status(err.status || 500).json({ status: 'error', message: err.message });
    }
});

// Admin test endpoint
router.post('/admin/test', async (req, res, next) => {
    try {
        const { provider, model } = req.body;
        await agentOrchestrator.testConnection(provider, model);
        res.status(200).json({ status: 'success', message: 'Connection successful!' });
    } catch (err) {
        res.status(400).json({ status: 'error', message: err.message });
    }
});

module.exports = router;