const { processJob } = require('../services/ai/aiOrchestrator');

exports.humanize = async (req, res, next) => {
    try {
        const { text, language, tone } = req.body;
        const result = await processJob({
            userId: req.user.id,
            jobType: 'humanize',
            text,
            language: language || 'en',
            tone: tone || 'neutral'
        });
        res.status(200).json({ status: 'success', ...result });
    } catch (err) {
        if (err.status) {
            return res.status(err.status).json({ status: 'error', message: err.message });
        }
        next(err);
    }
};

exports.translate = async (req, res, next) => {
    try {
        const { text, targetLanguage } = req.body;
        if (!targetLanguage) {
            return res.status(400).json({ status: 'error', message: 'Target language is required.' });
        }
        const result = await processJob({
            userId: req.user.id,
            jobType: 'translate',
            text,
            language: targetLanguage
        });
        res.status(200).json({ status: 'success', ...result });
    } catch (err) {
        if (err.status) {
            return res.status(err.status).json({ status: 'error', message: err.message });
        }
        next(err);
    }
};