const db = require('../database'); // Refactored to use database.js

exports.getHealth = async (req, res, next) => {
    let dbStatus = 'disconnected';
    let dbError = null;

    try {
        // Attempt to query the database
        // NOTE: This will throw an error if PostgreSQL is not running or credentials are wrong.
        const result = await db.query('SELECT NOW() as current_time');
        dbStatus = 'connected';
        
        res.status(200).json({
            status: 'success',
            message: 'Backend API is running',
            timestamp: new Date().toISOString(),
            database: {
                status: dbStatus,
                server_time: result.rows[0].current_time
            },
            uptime: process.uptime()
        });
    } catch (error) {
        dbError = error.message;
        
        // If DB fails, return a 503 Service Unavailable to honestly reflect the state
        res.status(503).json({
            status: 'warning',
            message: 'Backend API is running, but database connection failed.',
            timestamp: new Date().toISOString(),
            database: {
                status: dbStatus,
                error: dbError
            },
            uptime: process.uptime()
        });
    }
};