const db = require('../../database');
const { logAdminAction } = require('../../utils/auditLogger');

exports.getSettings = async (req, res, next) => {
    try {
        const result = await db.query('SELECT key, value FROM website_settings');
        // Convert array of {key, value} to a single object { site_name: "...", maintenance_mode: false }
        const settings = result.rows.reduce((acc, row) => ({ ...acc, [row.key]: row.value }), {});
        
        const auditLogs = await db.query(`
            SELECT a.*, u.email AS admin_email 
            FROM audit_logs a JOIN users u ON a.admin_id = u.id 
            ORDER BY a.created_at DESC LIMIT 50
        `);

        res.status(200).json({ 
            status: 'success', 
            settings, 
            auditLogs: auditLogs.rows 
        });
    } catch (err) { next(err); }
};

exports.updateSettings = async (req, res, next) => {
    try {
        const updates = req.body; // e.g., { site_name: "New Name", maintenance_mode: true }
        
        if (Object.keys(updates).length === 0) {
            return res.status(400).json({ status: 'error', message: 'No settings provided' });
        }

        const client = await db.pool.connect();
        try {
            await client.query('BEGIN');
            
            for (const [key, value] of Object.entries(updates)) {
                await client.query(
                    `INSERT INTO website_settings (key, value) VALUES ($1, $2)
                     ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()`,
                    [key, JSON.stringify(value)]
                );
            }
            
            await client.query('COMMIT');
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }

        await logAdminAction({
            adminId: req.user.id,
            action: 'UPDATE_WEBSITE_SETTINGS',
            targetType: 'settings',
            details: updates,
            req
        });

        res.status(200).json({ status: 'success', message: 'Settings updated' });
    } catch (err) { next(err); }
};