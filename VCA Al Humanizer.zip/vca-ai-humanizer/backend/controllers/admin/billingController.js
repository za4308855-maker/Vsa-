const db = require('../../database');
const { logAdminAction } = require('../../utils/auditLogger');

exports.listTransactions = async (req, res, next) => {
    try {
        const result = await db.query(`
            SELECT p.*, u.email 
            FROM payment_transactions p 
            JOIN users u ON p.user_id = u.id 
            ORDER BY p.created_at DESC LIMIT 100
        `);
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.listPlans = async (req, res, next) => {
    try {
        const result = await db.query('SELECT * FROM subscription_plans ORDER BY sort_order ASC');
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.updatePlan = async (req, res, next) => {
    try {
        const planId = req.params.id;
        const { price_monthly, price_yearly, included_credits, is_active } = req.body;

        const result = await db.query(
            `UPDATE subscription_plans 
             SET price_monthly = COALESCE($1, price_monthly),
                 price_yearly = COALESCE($2, price_yearly),
                 included_credits = COALESCE($3, included_credits),
                 is_active = COALESCE($4, is_active)
             WHERE id = $5 RETURNING name`,
            [price_monthly, price_yearly, included_credits, is_active, planId]
        );

        if (result.rows.length === 0) return res.status(404).json({ status: 'error', message: 'Plan not found' });

        await logAdminAction({
            adminId: req.user.id,
            action: 'UPDATE_SUBSCRIPTION_PLAN',
            targetType: 'plan',
            targetId: planId,
            details: { plan_name: result.rows[0].name, updated_fields: req.body },
            req
        });

        res.status(200).json({ status: 'success', message: 'Plan updated' });
    } catch (err) { next(err); }
};