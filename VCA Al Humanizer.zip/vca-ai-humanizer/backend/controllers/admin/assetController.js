const fs = require('fs');
const path = require('path');
const db = require('../../database');

const ASSET_DIR = path.join(__dirname, '../../../frontend/public/assets');
const CATEGORIES = ['images', 'logos', 'favicons', 'icons', 'blog'];

// 1. List Assets
exports.listAssets = async (req, res, next) => {
    try {
        const { category } = req.query;
        if (!CATEGORIES.includes(category)) {
            return res.status(400).json({ status: 'error', message: 'Invalid category' });
        }

        const dirPath = path.join(ASSET_DIR, category);
        if (!fs.existsSync(dirPath)) {
            fs.mkdirSync(dirPath, { recursive: true });
        }

        const files = fs.readdirSync(dirPath).map(file => {
            const stats = fs.statSync(path.join(dirPath, file));
            return {
                name: file,
                size: stats.size,
                url: `/public/assets/${category}/${file}`
            };
        });

        res.status(200).json({ status: 'success', data: files });
    } catch (err) { next(err); }
};

// 2. Upload/Replace Asset
exports.uploadAsset = async (req, res, next) => {
    try {
        const { category } = req.body;
        if (!CATEGORIES.includes(category)) {
            return res.status(400).json({ status: 'error', message: 'Invalid category' });
        }
        if (!req.file) {
            return res.status(400).json({ status: 'error', message: 'No file uploaded.' });
        }

        // req.file.filename is generated safely by multer in the next step
        res.status(200).json({ status: 'success', message: 'Asset uploaded', filename: req.file.filename });
    } catch (err) { next(err); }
};

// 3. Delete Asset
exports.deleteAsset = async (req, res, next) => {
    try {
        const { category, filename } = req.params;
        if (!CATEGORIES.includes(category)) return res.status(400).json({ status: 'error', message: 'Invalid category' });

        // Prevent Path Traversal
        const safeFilename = path.basename(filename);
        const filePath = path.join(ASSET_DIR, category, safeFilename);

        if (fs.existsSync(filePath)) {
            fs.unlinkSync(filePath);
            res.status(200).json({ status: 'success', message: 'File deleted' });
        } else {
            res.status(404).json({ status: 'error', message: 'File not found' });
        }
    } catch (err) { next(err); }
};