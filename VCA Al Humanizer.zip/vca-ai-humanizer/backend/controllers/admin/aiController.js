const db = require('../../database');

exports.getOllamaStatus = async (req, res, next) => {
    try {
        const ollamaUrl = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
        
        // 2-second timeout so the admin UI doesn't hang
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 2000);

        try {
            const response = await fetch(`${ollamaUrl}/api/tags`, { signal: controller.signal });
            clearTimeout(timeout);
            
            if (response.ok) {
                const data = await response.json();
                const models = (data.models || []).map(m => m.name);
                return res.status(200).json({ 
                    status: 'success', 
                    online: true, 
                    models, 
                    configuredModel: process.env.OLLAMA_MODEL 
                });
            }
        } catch (fetchErr) {
            clearTimeout(timeout);
            // Proceed to error return
        }

        res.status(200).json({ 
            status: 'success', 
            online: false, 
            error: 'Connection refused or timed out. Ensure Ollama is running.',
            configuredModel: process.env.OLLAMA_MODEL
        });
    } catch (err) { next(err); }
};

exports.listJobs = async (req, res, next) => {
    try {
        const { status = '', limit = 50, offset = 0 } = req.query;
        let query = 'SELECT j.*, u.email FROM ai_jobs j JOIN users u ON j.user_id = u.id';
        const params = [];
        
        if (status) {
            query += ' WHERE j.status = $1';
            params.push(status);
        }
        
        query += ' ORDER BY j.created_at DESC LIMIT $' + (params.length + 1) + ' OFFSET $' + (params.length + 2);
        params.push(limit, offset);

        const result = await db.query(query, params);
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.getSettings = async (req, res, next) => {
    res.status(200).json({
        status: 'success',
        data: {
            ollamaModel: process.env.OLLAMA_MODEL,
            maxWords: process.env.AI_MAX_WORDS_PER_REQUEST,
            timeoutMs: process.env.AI_REQUEST_TIMEOUT_MS,
            seoCosts: {
                quick: process.env.AI_SEO_COST_QUICK,
                standard: process.env.AI_SEO_COST_STANDARD,
                deep: process.env.AI_SEO_COST_DEEP
            }
        }
    });
};