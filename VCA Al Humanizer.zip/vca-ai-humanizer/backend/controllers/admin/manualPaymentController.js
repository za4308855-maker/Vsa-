const fs = require('fs');
const path = require('path');
const db = require('../../database');
const creditService = require('../../services/creditService');
const { logAdminAction } = require('../../utils/auditLogger');

const UPLOAD_DIR = path.join(__dirname, '../../../secure_uploads');

// --- 1. Order Management ---

exports.listOrders = async (req, res, next) => {
    try {
        const { search = '', limit = 50, offset = 0 } = req.query;
        const searchParam = `%${search}%`;
        
        const query = `
            SELECT o.*, p.name AS plan_name, u.email AS user_account_email
            FROM manual_orders o
            JOIN subscription_plans p ON o.plan_id = p.id
            JOIN users u ON o.user_id = u.id
            WHERE o.order_id ILIKE $1 OR o.customer_email ILIKE $1
            ORDER BY o.created_at DESC
            LIMIT $2 OFFSET $3
        `;
        const result = await db.query(query, [searchParam, limit, offset]);
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.getScreenshot = async (req, res, next) => {
    try {
        const { orderId } = req.params;
        const result = await db.query('SELECT screenshot_path FROM manual_orders WHERE order_id = $1', [orderId]);
        
        if (result.rows.length === 0 || !result.rows[0].screenshot_path) {
            return res.status(404).json({ status: 'error', message: 'Screenshot not found.' });
        }

        // Prevent Path Traversal
        const filename = path.basename(result.rows[0].screenshot_path);
        const filePath = path.join(UPLOAD_DIR, filename);

        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ status: 'error', message: 'File missing from disk.' });
        }

        res.sendFile(filePath);
    } catch (err) { next(err); }
};

// --- 2. Atomic Approval ---

exports.approveOrder = async (req, res, next) => {
    const { orderId } = req.params;
    const client = await db.pool.connect();

    try {
        await client.query('BEGIN');

        // 1. Lock Order row
        const orderResult = await client.query(
            'SELECT * FROM manual_orders WHERE order_id = $1 FOR UPDATE',
            [orderId]
        );

        if (orderResult.rows.length === 0) {
            throw Object.assign(new Error('Order not found'), { status: 404 });
        }

        const order = orderResult.rows[0];

        if (order.status !== 'awaiting_verification') {
            throw Object.assign(new Error(`Cannot approve order with status: ${order.status}`), { status: 400 });
        }

        // 2. Fetch Plan
        const planResult = await client.query('SELECT * FROM subscription_plans WHERE id = $1', [order.plan_id]);
        const plan = planResult.rows[0];

        // 3. Activate Subscription
        const periodEnd = new Date();
        if (order.billing_cycle === 'yearly') {
            periodEnd.setFullYear(periodEnd.getFullYear() + 1);
        } else {
            periodEnd.setMonth(periodEnd.getMonth() + 1);
        }

        // Deactivate old subs first
        await client.query("UPDATE user_subscriptions SET status = 'canceled' WHERE user_id = $1 AND status IN ('active', 'past_due')", [order.user_id]);

        await client.query(
            `INSERT INTO user_subscriptions 
             (user_id, plan_id, status, billing_cycle, current_period_start, current_period_end, start_date)
             VALUES ($1, $2, 'active', $3, NOW(), $4, NOW())`,
            [order.user_id, plan.id, order.billing_cycle, periodEnd]
        );

        // 4. Grant Credits (Idempotent via reference ID)
        await creditService.grantCredits(client, {
            userId: order.user_id,
            amount: plan.included_credits,
            transactionType: 'subscription_grant',
            referenceId: `manual_order:${order.order_id}`,
            description: `Credits for ${plan.name} (Manual EasyPaisa Payment)`
        });

        // 5. Record in payment_transactions
        await client.query(
            `INSERT INTO payment_transactions
             (user_id, amount, currency, status, transaction_reference, provider, payment_method, description)
             VALUES ($1, $2, 'PKR', 'completed', $3, 'easypaisa', 'qr_manual', $4)`,
            [order.user_id, order.amount, order.transaction_reference || orderId, `Manual payment for ${plan.name}`]
        );

        // 6. Mark Order Approved
        await client.query(
            "UPDATE manual_orders SET status = 'approved', admin_id = $1, updated_at = NOW() WHERE id = $2",
            [req.user.id, order.id]
        );

        await client.query('COMMIT');

        await logAdminAction({
            adminId: req.user.id,
            action: 'APPROVE_MANUAL_PAYMENT',
            targetType: 'manual_order',
            targetId: orderId,
            details: { amount: order.amount, plan: plan.name, user_id: order.user_id },
            req
        });

        res.status(200).json({ status: 'success', message: 'Order approved. Subscription activated.' });
    } catch (err) {
        await client.query('ROLLBACK');
        if (err.status) {
            return res.status(err.status).json({ status: 'error', message: err.message });
        }
        next(err);
    } finally {
        client.release();
    }
};

exports.rejectOrder = async (req, res, next) => {
    try {
        const { orderId } = req.params;
        
        const result = await db.query(
            "UPDATE manual_orders SET status = 'rejected', admin_id = $1, updated_at = NOW() WHERE order_id = $2 AND status = 'awaiting_verification' RETURNING id",
            [req.user.id, orderId]
        );

        if (result.rows.length === 0) {
            return res.status(400).json({ status: 'error', message: 'Order not found or already processed.' });
        }

        await logAdminAction({
            adminId: req.user.id,
            action: 'REJECT_MANUAL_PAYMENT',
            targetType: 'manual_order',
            targetId: orderId,
            req
        });

        res.status(200).json({ status: 'success', message: 'Order rejected.' });
    } catch (err) { next(err); }
};

// --- 3. QR Code Management ---

exports.getQRCodes = async (req, res, next) => {
    try {
        const result = await db.query('SELECT * FROM payment_qr_codes ORDER BY slot_number ASC');
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.uploadQRCode = async (req, res, next) => {
    try {
        const slotNumber = parseInt(req.params.slot, 10);
        if (![1, 2, 3].includes(slotNumber)) {
            return res.status(400).json({ status: 'error', message: 'Invalid slot number.' });
        }
        if (!req.file) {
            return res.status(400).json({ status: 'error', message: 'No image uploaded.' });
        }

        const filename = req.file.filename;

        // Fetch old file to delete it later
        const oldQr = await db.query('SELECT image_path FROM payment_qr_codes WHERE slot_number = $1', [slotNumber]);
        const oldPath = oldQr.rows[0]?.image_path;

        await db.query(
            'UPDATE payment_qr_codes SET image_path = $1, is_active = TRUE, updated_at = NOW() WHERE slot_number = $2',
            [filename, slotNumber]
        );

        // Delete old physical file if it exists
        if (oldPath) {
            const fullOldPath = path.join(UPLOAD_DIR, path.basename(oldPath));
            if (fs.existsSync(fullOldPath)) fs.unlinkSync(fullOldPath);
        }

        await logAdminAction({
            adminId: req.user.id,
            action: 'UPLOAD_QR_CODE',
            targetType: 'qr_code',
            targetId: String(slotNumber),
            req
        });

        res.status(200).json({ status: 'success', message: 'QR Code updated successfully.' });
    } catch (err) { next(err); }
};

exports.toggleQRCode = async (req, res, next) => {
    try {
        const slotNumber = parseInt(req.params.slot, 10);
        const { is_active } = req.body;

        if (![1, 2, 3].includes(slotNumber) || typeof is_active !== 'boolean') {
            return res.status(400).json({ status: 'error', message: 'Invalid parameters.' });
        }

        await db.query('UPDATE payment_qr_codes SET is_active = $1, updated_at = NOW() WHERE slot_number = $2', [is_active, slotNumber]);

        await logAdminAction({
            adminId: req.user.id,
            action: is_active ? 'ENABLE_QR_CODE' : 'DISABLE_QR_CODE',
            targetType: 'qr_code',
            targetId: String(slotNumber),
            req
        });

        res.status(200).json({ status: 'success', message: `QR slot ${slotNumber} ${is_active ? 'enabled' : 'disabled'}.` });
    } catch (err) { next(err); }
};