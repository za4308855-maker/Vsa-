const db = require('../../database');

exports.getStats = async (req, res, next) => {
    try {
        // Run all aggregation queries in parallel
        const [
            usersCount,
            activeSubs,
            revenue,
            aiJobsCount,
            seoCount,
            blogCount,
            creditsUsed
        ] = await Promise.all([
            db.query('SELECT COUNT(*) FROM users'),
            db.query("SELECT COUNT(*) FROM user_subscriptions WHERE status = 'active'"),
            db.query("SELECT SUM(amount) FROM payment_transactions WHERE status = 'completed'"),
            db.query('SELECT COUNT(*) FROM ai_jobs'),
            db.query('SELECT COUNT(*) FROM seo_research'),
            db.query('SELECT COUNT(*) FROM blog_drafts'),
            db.query("SELECT SUM(-delta) FROM credit_transactions WHERE transaction_type = 'ai_usage'")
        ]);

        res.status(200).json({
            status: 'success',
            data: {
                totalUsers: parseInt(usersCount.rows[0].count, 10),
                activeSubscriptions: parseInt(activeSubs.rows[0].count, 10),
                totalRevenue: parseFloat(revenue.rows[0].sum || 0),
                totalAiJobs: parseInt(aiJobsCount.rows[0].count, 10),
                totalSeoResearch: parseInt(seoCount.rows[0].count, 10),
                totalBlogDrafts: parseInt(blogCount.rows[0].count, 10),
                totalCreditsUsed: parseInt(creditsUsed.rows[0].sum || 0, 10)
            }
        });
    } catch (err) { next(err); }
};