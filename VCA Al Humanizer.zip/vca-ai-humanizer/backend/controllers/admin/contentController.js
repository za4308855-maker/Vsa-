const db = require('../../database');
const { logAdminAction } = require('../../utils/auditLogger');

exports.listSEO = async (req, res, next) => {
    try {
        const result = await db.query(`
            SELECT s.id, s.topic, s.primary_keyword, s.search_intent, s.created_at, u.email 
            FROM seo_research s JOIN users u ON s.user_id = u.id 
            ORDER BY s.created_at DESC LIMIT 100
        `);
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.listBlogs = async (req, res, next) => {
    try {
        const result = await db.query(`
            SELECT b.id, b.title, b.status, b.actual_word_count, b.created_at, u.email 
            FROM blog_drafts b JOIN users u ON b.user_id = u.id 
            ORDER BY b.created_at DESC LIMIT 100
        `);
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.updateBlogStatus = async (req, res, next) => {
    try {
        const { status } = req.body; // 'draft', 'published', 'archived'
        const blogId = req.params.id;

        if (!['draft', 'published', 'archived'].includes(status)) {
            return res.status(400).json({ status: 'error', message: 'Invalid status' });
        }

        const result = await db.query(
            'UPDATE blog_drafts SET status = $1 WHERE id = $2 RETURNING title',
            [status, blogId]
        );
        
        if (result.rows.length === 0) return res.status(404).json({ status: 'error', message: 'Blog draft not found' });

        await logAdminAction({
            adminId: req.user.id,
            action: 'UPDATE_BLOG_STATUS',
            targetType: 'blog_draft',
            targetId: blogId,
            details: { new_status: status, title: result.rows[0].title },
            req
        });

        res.status(200).json({ status: 'success', message: 'Blog status updated' });
    } catch (err) { next(err); }
};