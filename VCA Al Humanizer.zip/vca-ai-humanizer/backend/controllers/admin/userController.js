const db = require('../../database');
const { logAdminAction } = require('../../utils/auditLogger');

exports.listUsers = async (req, res, next) => {
    try {
        const { search = '', limit = 50, offset = 0 } = req.query;
        const searchParam = `%${search}%`;
        
        const query = `
            SELECT u.id, u.email, u.status, u.is_admin, u.is_verified, u.created_at,
                   p.first_name, p.last_name,
                   c.balance AS credits,
                   s.plan_id, sp.name AS plan_name
            FROM users u
            LEFT JOIN user_profiles p ON u.id = p.user_id
            LEFT JOIN user_credits c ON u.id = c.user_id
            LEFT JOIN user_subscriptions s ON u.id = s.user_id AND s.status = 'active'
            LEFT JOIN subscription_plans sp ON s.plan_id = sp.id
            WHERE u.email ILIKE $1 OR p.first_name ILIKE $1 OR p.last_name ILIKE $1
            ORDER BY u.created_at DESC
            LIMIT $2 OFFSET $3
        `;
        
        const result = await db.query(query, [searchParam, limit, offset]);
        const total = await db.query('SELECT COUNT(*) FROM users WHERE email ILIKE $1', [searchParam]);

        res.status(200).json({ 
            status: 'success', 
            data: result.rows,
            total: parseInt(total.rows[0].count, 10),
            limit: parseInt(limit),
            offset: parseInt(offset)
        });
    } catch (err) { next(err); }
};

exports.getUserDetails = async (req, res, next) => {
    try {
        const userId = req.params.id;
        
        const user = await db.query(
            `SELECT u.*, p.first_name, p.last_name, c.balance AS credits
             FROM users u
             LEFT JOIN user_profiles p ON u.id = p.user_id
             LEFT JOIN user_credits c ON u.id = c.user_id
             WHERE u.id = $1`, [userId]
        );
        if (user.rows.length === 0) return res.status(404).json({ status: 'error', message: 'User not found' });

        const recentJobs = await db.query('SELECT id, job_type, status, processing_time, created_at FROM ai_jobs WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10', [userId]);
        const recentPayments = await db.query('SELECT id, amount, status, provider, created_at FROM payment_transactions WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10', [userId]);

        res.status(200).json({
            status: 'success',
            data: {
                user: user.rows[0],
                recentJobs: recentJobs.rows,
                recentPayments: recentPayments.rows
            }
        });
    } catch (err) { next(err); }
};

exports.updateUserStatus = async (req, res, next) => {
    try {
        const { status } = req.body;
        const userId = req.params.id;
        
        if (!['active', 'suspended'].includes(status)) {
            return res.status(400).json({ status: 'error', message: 'Invalid status' });
        }

        // Prevent admin from suspending themselves
        if (parseInt(userId, 10) === req.user.id) {
            return res.status(400).json({ status: 'error', message: 'You cannot suspend your own account.' });
        }

        const result = await db.query(
            'UPDATE users SET status = $1 WHERE id = $2 RETURNING email',
            [status, userId]
        );
        
        if (result.rows.length === 0) return res.status(404).json({ status: 'error', message: 'User not found' });

        await logAdminAction({
            adminId: req.user.id,
            action: 'UPDATE_USER_STATUS',
            targetType: 'user',
            targetId: userId,
            details: { new_status: status, email: result.rows[0].email },
            req
        });

        res.status(200).json({ status: 'success', message: `User status updated to ${status}` });
    } catch (err) { next(err); }
};