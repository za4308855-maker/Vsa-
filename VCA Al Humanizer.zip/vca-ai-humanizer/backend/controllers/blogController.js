const db = require('../database');
const { processBlogJob } = require('../services/ai/aiOrchestrator');

// POST /api/blog/generate
exports.generateBlog = async (req, res, next) => {
    try {
        const { 
            seoResearchId, title, primaryKeyword, secondaryKeywords, 
            targetWordCount, tone, language 
        } = req.body;

        if (!targetWordCount) {
            return res.status(400).json({ status: 'error', message: 'targetWordCount is required.' });
        }

        const result = await processBlogJob({
            userId: req.user.id,
            seoResearchId,
            title,
            primaryKeyword,
            secondaryKeywords,
            targetWordCount: parseInt(targetWordCount, 10),
            tone: tone || 'professional',
            language: language || 'en'
        });

        res.status(200).json({
            status: 'success',
            draftId: result.draftId,
            data: result.output,
            creditsUsed: result.creditsUsed,
            processingTime: result.processingTime
        });
    } catch (err) {
        if (err.status) {
            return res.status(err.status).json({ status: 'error', message: err.message });
        }
        next(err);
    }
};

// GET /api/blog/drafts
exports.listDrafts = async (req, res, next) => {
    try {
        const result = await db.query(
            'SELECT id, title, slug, target_word_count, actual_word_count, status, created_at FROM blog_drafts WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
            [req.user.id]
        );
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) {
        next(err);
    }
};

// GET /api/blog/drafts/:id
exports.getDraft = async (req, res, next) => {
    try {
        const result = await db.query('SELECT * FROM blog_drafts WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Draft not found or unauthorized.' });
        }
        res.status(200).json({ status: 'success', data: result.rows[0] });
    } catch (err) {
        next(err);
    }
};

// PUT /api/blog/drafts/:id
exports.updateDraft = async (req, res, next) => {
    try {
        const { title, content_markdown, status } = req.body;
        
        // Build dynamic update query based on provided fields
        const updates = [];
        const values = [];
        let paramCount = 1;

        if (title) { updates.push(`title = $${paramCount++}`); values.push(title); }
        if (content_markdown) { updates.push(`content_markdown = $${paramCount++}`); values.push(content_markdown); }
        if (status) { updates.push(`status = $${paramCount++}`); values.push(status); }

        if (updates.length === 0) {
            return res.status(400).json({ status: 'error', message: 'No valid fields provided for update.' });
        }

        values.push(req.params.id, req.user.id);
        
        const query = `UPDATE blog_drafts SET ${updates.join(', ')} WHERE id = $${paramCount++} AND user_id = $${paramCount} RETURNING *`;
        const result = await db.query(query, values);

        if (result.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Draft not found or unauthorized.' });
        }
        res.status(200).json({ status: 'success', data: result.rows[0] });
    } catch (err) {
        next(err);
    }
};

// DELETE /api/blog/drafts/:id
exports.deleteDraft = async (req, res, next) => {
    try {
        const result = await db.query('DELETE FROM blog_drafts WHERE id = $1 AND user_id = $2 RETURNING id', [req.params.id, req.user.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Draft not found or unauthorized.' });
        }
        res.status(200).json({ status: 'success', message: 'Draft deleted.' });
    } catch (err) {
        next(err);
    }
};