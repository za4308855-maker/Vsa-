const creditService = require('../services/creditService');

exports.getBalance = async (req, res, next) => {
    try {
        const balance = await creditService.getBalance(req.user.id);
        res.status(200).json({ status: 'success', balance });
    } catch (err) { next(err); }
};

exports.getHistory = async (req, res, next) => {
    try {
        const limit = Math.min(parseInt(req.query.limit || '50', 10), 200);
        const offset = Math.max(parseInt(req.query.offset || '0', 10), 0);
        const rows = await creditService.getHistory(req.user.id, limit, offset);
        res.status(200).json({ status: 'success', data: rows, limit, offset });
    } catch (err) { next(err); }
};