const db = require('../database');
const creditService = require('../services/creditService');

exports.listPayments = async (req, res, next) => {
    try {
        const limit = Math.min(parseInt(req.query.limit || '50', 10), 200);
        const offset = Math.max(parseInt(req.query.offset || '0', 10), 0);
        const result = await db.query(
            `SELECT p.*, u.email
             FROM payment_transactions p
             JOIN users u ON p.user_id = u.id
             ORDER BY p.created_at DESC
             LIMIT $1 OFFSET $2`,
            [limit, offset]
        );
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.listSubscriptions = async (req, res, next) => {
    try {
        const result = await db.query(
            `SELECT s.*, u.email, p.name AS plan_name, p.slug AS plan_slug
             FROM user_subscriptions s
             JOIN users u ON s.user_id = u.id
             JOIN subscription_plans p ON s.plan_id = p.id
             ORDER BY s.created_at DESC LIMIT 100`
        );
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) { next(err); }
};

exports.adjustUserCredits = async (req, res, next) => {
    try {
        const { userId, delta, reason } = req.body;
        if (!userId || !delta || !reason) {
            return res.status(400).json({ status: 'error', message: 'userId, delta, and reason are required.' });
        }
        if (typeof delta !== 'number' || delta === 0) {
            return res.status(400).json({ status: 'error', message: 'delta must be a non-zero number.' });
        }

        const client = await db.pool.connect();
        try {
            await client.query('BEGIN');
            const refId = `admin_adjustment:${Date.now()}`;
            let result;
            if (delta > 0) {
                result = await creditService.grantCredits(client, {
                    userId,
                    amount: delta,
                    transactionType: 'admin_adjustment',
                    referenceId: refId,
                    description: `Admin adjustment: ${reason}`
                });
            } else {
                result = await creditService.deductCredits(client, {
                    userId,
                    amount: Math.abs(delta),
                    transactionType: 'admin_adjustment',
                    referenceId: refId,
                    description: `Admin adjustment: ${reason}`
                });
            }
            await client.query('COMMIT');
            res.status(200).json({ status: 'success', newBalance: result.balance });
        } catch (err) {
            await client.query('ROLLBACK');
            throw err;
        } finally {
            client.release();
        }
    } catch (err) { next(err); }
};