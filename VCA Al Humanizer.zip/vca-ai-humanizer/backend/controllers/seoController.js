const db = require('../database');
const { processSEOJob } = require('../services/ai/aiOrchestrator');

// POST /api/seo/research
exports.startResearch = async (req, res, next) => {
    try {
        const { topic, targetCountry, targetLanguage, researchDepth } = req.body;
        
        const result = await processSEOJob({
            userId: req.user.id,
            topic,
            targetCountry: targetCountry || 'US',
            targetLanguage: targetLanguage || 'en',
            researchDepth: researchDepth || 'standard'
        });

        res.status(200).json({
            status: 'success',
            researchId: result.researchId,
            data: result.output,
            dataSource: 'ollama_inference',
            disclaimer: 'Keyword suggestions and relevance scores are AI-inferred, not live search data.',
            creditsUsed: result.creditsUsed,
            processingTime: result.processingTime,
            cached: result.cached
        });
    } catch (err) {
        if (err.status) {
            return res.status(err.status).json({ status: 'error', message: err.message });
        }
        next(err);
    }
};

// GET /api/seo/research
exports.listResearch = async (req, res, next) => {
    try {
        const result = await db.query(
            'SELECT id, topic, target_country, target_language, research_depth, primary_keyword, search_intent, created_at FROM seo_research WHERE user_id = $1 ORDER BY created_at DESC LIMIT 50',
            [req.user.id]
        );
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) {
        next(err);
    }
};

// GET /api/seo/research/:id
exports.getResearch = async (req, res, next) => {
    try {
        const result = await db.query('SELECT * FROM seo_research WHERE id = $1 AND user_id = $2', [req.params.id, req.user.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Research not found or unauthorized.' });
        }
        res.status(200).json({ status: 'success', data: result.rows[0] });
    } catch (err) {
        next(err);
    }
};

// DELETE /api/seo/research/:id
exports.deleteResearch = async (req, res, next) => {
    try {
        const result = await db.query('DELETE FROM seo_research WHERE id = $1 AND user_id = $2 RETURNING id', [req.params.id, req.user.id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Research not found or unauthorized.' });
        }
        res.status(200).json({ status: 'success', message: 'Research deleted.' });
    } catch (err) {
        next(err);
    }
};