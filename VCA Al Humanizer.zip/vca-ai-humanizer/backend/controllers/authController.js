const db = require('../database');
const { hashPassword, comparePassword, generateOTP, hashToken, generateJWT } = require('../services/authService');
const { sendOTPEmail, sendPasswordResetEmail } = require('../services/emailService');
const subscriptionService = require('../services/subscriptionService');

const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'strict',
    maxAge: 7 * 24 * 60 * 60 * 1000
};

exports.signup = async (req, res, next) => {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
        return res.status(400).json({ status: 'error', message: 'All fields are required' });
    }

    const client = await db.pool.connect();
    try {
        await client.query('BEGIN');

        const userCheck = await client.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userCheck.rows.length > 0) {
            await client.query('ROLLBACK');
            return res.status(400).json({ status: 'error', message: 'Email already registered' });
        }

        const passwordHash = await hashPassword(password);
        const nameParts = name.trim().split(' ');
        const firstName = nameParts[0];
        const lastName = nameParts.length > 1 ? nameParts.slice(1).join(' ') : '';

        const newUser = await client.query(
            'INSERT INTO users (email, password_hash) VALUES ($1, $2) RETURNING id',
            [email, passwordHash]
        );
        const userId = newUser.rows[0].id;

        await client.query(
            'INSERT INTO user_profiles (user_id, first_name, last_name) VALUES ($1, $2, $3)',
            [userId, firstName, lastName]
        );

        const otp = generateOTP();
        const otpHash = hashToken(otp);
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await client.query('DELETE FROM email_verifications WHERE user_id = $1', [userId]);
        await client.query(
            'INSERT INTO email_verifications (user_id, otp_hash, expires_at) VALUES ($1, $2, $3)',
            [userId, otpHash, expiresAt]
        );

        // PHASE 6 ADDITION: Assign Free subscription + grant initial credits.
        // Idempotent, wrapped inside the same transaction. If the Free plan is
        // missing from subscription_plans (e.g., migration not yet run), this
        // logs a warning but does not fail signup.
        try {
            await subscriptionService.ensureFreeSubscription(client, userId);
        } catch (subErr) {
            console.warn('[signup] Free subscription assignment failed:', subErr.message);
            // Non-fatal: signup continues. Owner can assign manually.
        }

        await client.query('COMMIT');

        await sendOTPEmail(email, otp);

        res.status(201).json({ status: 'success', message: 'Signup successful. Please check your email for the OTP.', email });
    } catch (error) {
        await client.query('ROLLBACK');
        next(error);
    } finally {
        client.release();
    }
};

exports.verifyOTP = async (req, res, next) => {
    const { email, otp } = req.body;
    if (!email || !otp) return res.status(400).json({ status: 'error', message: 'Email and OTP are required' });

    try {
        const userQuery = await db.query('SELECT id FROM users WHERE email = $1', [email.toLowerCase().trim()]);
        if (userQuery.rows.length === 0) return res.status(400).json({ status: 'error', message: 'User not found' });
        const userId = userQuery.rows[0].id;

        const otpHash = hashToken(otp);
        const verificationQuery = await db.query(
            'SELECT id, expires_at FROM email_verifications WHERE user_id = $1 AND otp_hash = $2',
            [userId, otpHash]
        );

        if (verificationQuery.rows.length === 0) return res.status(400).json({ status: 'error', message: 'Invalid OTP' });
        const verification = verificationQuery.rows[0];
        if (new Date() > new Date(verification.expires_at)) {
            return res.status(400).json({ status: 'error', message: 'OTP has expired' });
        }

        await db.query('UPDATE users SET is_verified = TRUE WHERE id = $1', [userId]);
        await db.query('DELETE FROM email_verifications WHERE user_id = $1', [userId]);

        res.status(200).json({ status: 'success', message: 'Email verified successfully. You can now log in.' });
    } catch (error) { next(error); }
};

exports.login = async (req, res, next) => {
    const email = req.body.email ? req.body.email.toLowerCase().trim() : null;
    const { password } = req.body;

    if (!email || !password) return res.status(400).json({ status: 'error', message: 'Email and password are required' });

    try {
        const result = await db.query(
            'SELECT u.id, u.email, u.password_hash, u.is_verified, u.is_admin, p.first_name, p.last_name FROM users u LEFT JOIN user_profiles p ON u.id = p.user_id WHERE u.email = $1',
            [email]
        );

        if (result.rows.length === 0) return res.status(401).json({ status: 'error', message: 'Invalid credentials' });
        const user = result.rows[0];

        if (!user.is_verified) return res.status(403).json({ status: 'error', message: 'Please verify your email first' });

        let isMatch = false;
        try {
            isMatch = await comparePassword(password, user.password_hash);
        } catch (bcryptError) {
            console.error('Bcrypt compare error:', bcryptError);
            return res.status(500).json({ status: 'error', message: 'Authentication error. Please contact support.' });
        }

        if (!isMatch) return res.status(401).json({ status: 'error', message: 'Invalid credentials' });

        const token = generateJWT(user.id);
        res.cookie('jwt', token, cookieOptions);

        res.status(200).json({
            status: 'success',
            message: 'Login successful',
            user: {
                id: user.id,
                email: user.email,
                firstName: user.first_name,
                lastName: user.last_name,
                isAdmin: !!user.is_admin
            }
        });
    } catch (error) { next(error); }
};

exports.logout = (req, res) => {
    res.cookie('jwt', '', { ...cookieOptions, maxAge: 1 });
    res.status(200).json({ status: 'success', message: 'Logged out successfully' });
};

exports.forgotPassword = async (req, res, next) => {
    const email = req.body.email ? req.body.email.toLowerCase().trim() : null;
    if (!email) return res.status(400).json({ status: 'error', message: 'Email is required' });

    try {
        const userQuery = await db.query('SELECT id FROM users WHERE email = $1', [email]);
        if (userQuery.rows.length > 0) {
            const userId = userQuery.rows[0].id;
            const resetToken = require('crypto').randomBytes(32).toString('hex');
            const resetHash = hashToken(resetToken);
            const expiresAt = new Date(Date.now() + 60 * 60 * 1000);

            await db.query('DELETE FROM password_resets WHERE user_id = $1', [userId]);
            await db.query(
                'INSERT INTO password_resets (user_id, reset_token_hash, expires_at) VALUES ($1, $2, $3)',
                [userId, resetHash, expiresAt]
            );
            await sendPasswordResetEmail(email, resetToken);
        }
        res.status(200).json({ status: 'success', message: 'If that email exists, a reset link has been sent.' });
    } catch (error) { next(error); }
};

exports.resetPassword = async (req, res, next) => {
    const { token, newPassword } = req.body;
    if (!token || !newPassword) return res.status(400).json({ status: 'error', message: 'Token and new password are required' });

    try {
        const resetHash = hashToken(token);
        const resetQuery = await db.query(
            'SELECT user_id, expires_at FROM password_resets WHERE reset_token_hash = $1',
            [resetHash]
        );
        if (resetQuery.rows.length === 0) return res.status(400).json({ status: 'error', message: 'Invalid or expired reset token' });

        const { user_id, expires_at } = resetQuery.rows[0];
        if (new Date() > new Date(expires_at)) return res.status(400).json({ status: 'error', message: 'Reset token has expired' });

        const newHash = await hashPassword(newPassword);
        await db.query('UPDATE users SET password_hash = $1 WHERE id = $2', [newHash, user_id]);
        await db.query('DELETE FROM password_resets WHERE user_id = $1', [user_id]);

        res.status(200).json({ status: 'success', message: 'Password reset successfully. You can now log in.' });
    } catch (error) { next(error); }
};

exports.getMe = async (req, res, next) => {
    try {
        const result = await db.query(
            'SELECT u.id, u.email, u.is_admin, p.first_name, p.last_name FROM users u LEFT JOIN user_profiles p ON u.id = p.user_id WHERE u.id = $1',
            [req.user.id]
        );
        if (result.rows.length === 0) return res.status(404).json({ message: 'User not found' });
        res.status(200).json({ status: 'success', user: result.rows[0] });
    } catch (error) { next(error); }
};
const cookieOptions = {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production', // MUST be false for localhost HTTP
    sameSite: 'strict',
    maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
};

// Inside exports.login:
const token = generateJWT(user.id);
res.cookie('jwt', token, cookieOptions);
res.status(200).json({ status: 'success', user: { id: user.id, email: user.email } });