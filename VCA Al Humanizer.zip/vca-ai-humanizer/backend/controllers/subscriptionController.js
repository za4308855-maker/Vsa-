const db = require('../database');

exports.listPlans = async (req, res, next) => {
    try {
        const result = await db.query(
            `SELECT id, name, slug, description, price_monthly, price_yearly, included_credits 
             FROM subscription_plans 
             WHERE is_active = TRUE 
             ORDER BY sort_order ASC`
        );
        res.status(200).json({ status: 'success', data: result.rows });
    } catch (err) {
        console.error("DB Error:", err.message);
        res.status(500).json({ status: 'error', message: 'Database error. Did you run migrations?' });
    }
};