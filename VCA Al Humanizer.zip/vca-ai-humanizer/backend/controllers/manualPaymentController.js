const crypto = require('crypto');
const db = require('../database');

// Helper to generate a unique order ID
function generateOrderId() {
    return 'VCA-' + crypto.randomBytes(4).toString('hex').toUpperCase();
}

// 1. Create a pending order before showing the QR
exports.createOrder = async (req, res, next) => {
    try {
        const { planId, billingCycle, customerName } = req.body;

        if (!planId || !['monthly', 'yearly'].includes(billingCycle) || !customerName) {
            return res.status(400).json({ status: 'error', message: 'Invalid request parameters.' });
        }

        // Fetch plan to get the real price (Never trust frontend amount)
        const plan = await db.query('SELECT * FROM subscription_plans WHERE id = $1 AND is_active = TRUE', [planId]);
        if (plan.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Plan not found or inactive.' });
        }

        const p = plan.rows[0];
        const amount = billingCycle === 'yearly' ? p.price_yearly : p.price_monthly;

        // Get user's email
        const user = await db.query('SELECT email FROM users WHERE id = $1', [req.user.id]);

        const orderId = generateOrderId();

        const insert = await db.query(
            `INSERT INTO manual_orders 
            (order_id, user_id, plan_id, billing_cycle, amount, customer_name, customer_email, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7, 'pending') RETURNING *`,
            [orderId, req.user.id, planId, billingCycle, amount, customerName, user.rows[0].email]
        );

        // Fetch active QRs
        const qrs = await db.query('SELECT slot_number, image_path FROM payment_qr_codes WHERE is_active = TRUE ORDER BY slot_number ASC');

        res.status(201).json({
            status: 'success',
            data: {
                order: insert.rows[0],
                qrs: qrs.rows
            }
        });
    } catch (err) {
        next(err);
    }
};

// 2. Submit payment details (Ref ID or Screenshot)
exports.submitPayment = async (req, res, next) => {
    try {
        const { orderId, transactionReference } = req.body;
        const screenshotPath = req.file ? req.file.filename : null;

        if (!orderId) {
            return res.status(400).json({ status: 'error', message: 'Order ID is required.' });
        }

        if (!transactionReference && !screenshotPath) {
            return res.status(400).json({ status: 'error', message: 'Please provide either a transaction reference or a screenshot.' });
        }

        // Verify order exists and belongs to the user, and is pending
        const order = await db.query(
            "SELECT id FROM manual_orders WHERE order_id = $1 AND user_id = $2 AND status = 'pending'",
            [orderId, req.user.id]
        );

        if (order.rows.length === 0) {
            return res.status(404).json({ status: 'error', message: 'Order not found or already processed.' });
        }

        await db.query(
            `UPDATE manual_orders 
             SET transaction_reference = $1, screenshot_path = $2, status = 'awaiting_verification', updated_at = NOW()
             WHERE id = $3`,
            [transactionReference || null, screenshotPath, order.rows[0].id]
        );

        res.status(200).json({ status: 'success', message: 'Payment details submitted. Awaiting admin verification.' });
    } catch (err) {
        next(err);
    }
};